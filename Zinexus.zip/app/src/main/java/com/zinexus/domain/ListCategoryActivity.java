package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.thekhaeng.pushdownanim.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class ListCategoryActivity extends AppCompatActivity {
	
	private boolean animate = false;
	private HashMap<String, Object> map1 = new HashMap<>();
	private String save = "";
	private double number = 0;
	private double length = 0;
	private String value1 = "";
	private HashMap<String, Object> map1_post = new HashMap<>();
	private HashMap<String, Object> map1_request = new HashMap<>();
	private String Details = "";
	private String Id = "";
	
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap1_post = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap1_getname = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private ImageView imageview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private EditText edittext1;
	private JazzyListView listview1;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent intent = new Intent();
	private RequestNetwork post;
	private RequestNetwork.RequestListener _post_request_listener;
	private RequestNetwork date;
	private RequestNetwork.RequestListener _date_request_listener;
	private SharedPreferences sp;
	private AlertDialog CustomDialog;
	private Calendar calendar = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.list_category);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		imageview2 = findViewById(R.id.imageview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		edittext1 = findViewById(R.id.edittext1);
		listview1 = findViewById(R.id.listview1);
		net = new RequestNetwork(this);
		post = new RequestNetwork(this);
		date = new RequestNetwork(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				listmap1 = new Gson().fromJson(save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				length = listmap1.size();
				number = length - 1;
				for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
					value1 = listmap1.get((int)number).get("name").toString();
					if (!(_charSeq.length() > value1.length()) && value1.toLowerCase().contains(_charSeq.toLowerCase())) {
						
					}
					else {
						listmap1.remove((int)(number));
						listview1.setAdapter(new Listview1Adapter(listmap1));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					number--;
				}
				listview1.setAdapter(new Listview1Adapter(listmap1));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					
					     listmap1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					save = new Gson().toJson(listmap1);
					
					      } catch (Exception e) {
					
					      
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_post_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				AlphaToast(ListCategoryActivity.this,"Request Sent",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				AlphaToast(ListCategoryActivity.this,"Faild to Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
		};
		
		_date_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				calendar = Calendar.getInstance();
				map1_post = new HashMap<>();
				map1_post.put("Type", "Hero");
				map1_post.put("Details", Details.trim());
				map1_post.put("Accept", "Pending");
				map1_post.put("Time", new SimpleDateFormat("hh:mm a dd/MMM/yy").format(calendar.getTime()));
				map1_post.put("Id", Id.trim());
				listmap1_post.add(map1_post);
				map1_request.put("data", new Gson().toJson(map1_post));
				post.setParams(map1_request, RequestNetworkController.REQUEST_BODY);
				post.startRequestNetwork(RequestNetworkController.POST, "https://sheetdb.io/api/v1/mwd2azigurm64", "", _post_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				AlphaToast(ListCategoryActivity.this,"Faild to Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =ListCategoryActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF0B141A);
		}
		android.graphics.drawable.GradientDrawable linear3gd = new android.graphics.drawable.GradientDrawable();
		
		linear3gd.setColor(0xFF121F2B);
		
		linear3gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear3gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		
		linear3.setBackground(linear3gd);
		
		linear3.setElevation(50);
		android.graphics.drawable.GradientDrawable linear12gd = new android.graphics.drawable.GradientDrawable();
		
		linear12gd.setColor(0xFF121F2B);
		
		linear12gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear12gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear12.setBackground(linear12gd);
		
		linear12.setElevation(50);
		android.graphics.drawable.GradientDrawable linear13gd = new android.graphics.drawable.GradientDrawable();
		
		linear13gd.setColor(0xFF121F2B);
		
		linear13gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear13gd.setCornerRadii(new float[]{(int)30,(int)30,(int)30,(int)30,(int)0,(int)0,(int)0,(int)0});
		
		linear13.setBackground(linear13gd);
		
		linear13.setElevation(50);
		_Internet();
		if (getIntent().hasExtra("category")) {
			textview1.setText(getIntent().getStringExtra("category"));
		}
		if (getIntent().hasExtra("list")) {
			textview2.setText(getIntent().getStringExtra("list"));
		}
		edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 40)});
		edittext1.setCursorVisible(false);
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		OverScrollDecoratorHelper.setUpOverScroll(listview1);
		_PushDown();
	}
	
	@Override
	public void onBackPressed() {
		startActivity(new Intent(ListCategoryActivity.this, HomeActivity.class)); Animatoo.animateFade(ListCategoryActivity.this);
	}
	
	public void _PushDown() {
		PushDownAnim.setPushDownAnimTo(imageview1).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				CustomDialog = new AlertDialog.Builder(ListCategoryActivity.this).create();
				LayoutInflater CustomDialogLI = getLayoutInflater();
				View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.request, null);
				CustomDialog.setView(CustomDialogCV);
				CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
				final LinearLayout l1 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear1);
				final LinearLayout l4 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear4);
				final LinearLayout l6 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear6);
				final LinearLayout l7 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear7);
				final TextView t1 = (TextView)
				CustomDialogCV.findViewById(R.id.textview1);
				android.graphics.drawable.GradientDrawable linear1gd = new android.graphics.drawable.GradientDrawable();
				
				linear1gd.setColor(0xFF0B141D);
				
				linear1gd.setStroke((int)0, Color.TRANSPARENT);
				
				linear1gd.setCornerRadii(new float[]{(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8});
				
				linear1.setBackground(linear1gd);
				
				linear1.setElevation(50);
				final EditText edittext1= new EditText(ListCategoryActivity.this);
				
				LinearLayout.LayoutParams l1par = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
				
				edittext1.setLayoutParams(l1par);
				
				l7.addView(edittext1);
				t1.setText("I D - ".concat(Build.HOST));
				edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF121F2B));
				edittext1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				edittext1.setAlpha((float)(0.8d));
				edittext1.setTextColor(0xFFBDBDBD);
				edittext1.setTextSize((float) 12);
				edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 100)});
				edittext1.setHint("Name of Hero");
				edittext1.setHintTextColor(0xFF757575);
				edittext1.setCursorVisible(false);
				l4.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						if (SketchwareUtil.isConnected(getApplicationContext())) {
							if (edittext1.getText().toString().length() == 0) {
								AlphaToast(ListCategoryActivity.this,"Invalid Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
							}
							else {
								date.startRequestNetwork(RequestNetworkController.GET, "http://flexydev.atwebpages.com/api/date.php", "", _date_request_listener);
								Id = Build.HOST;
								Details = edittext1.getText().toString();
								edittext1.setText("");
								CustomDialog.dismiss();
								_Progress(true);
							}
						}
						else {
							AlphaToast(ListCategoryActivity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
						}
					}
				});
				l6.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						CustomDialog.dismiss();
					}
				});
				CustomDialog.setCancelable(false);
				CustomDialog.show();
				 } } );
		PushDownAnim.setPushDownAnimTo(imageview2).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("android-app://com.mobile.legends"));
				startActivity(intent);
				 } } );
	}
	
	
	public void _Internet() {
		if (getIntent().getStringExtra("category").equals("Assassin")) {
			net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Assassin-Data/", "a", _net_request_listener);
		}
		else {
			if (getIntent().getStringExtra("category").equals("Tank")) {
				net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Tank-Data/", "a", _net_request_listener);
			}
			else {
				if (getIntent().getStringExtra("category").equals("Fighter")) {
					net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Fighter-Data/", "a", _net_request_listener);
				}
				else {
					if (getIntent().getStringExtra("category").equals("Marksman")) {
						net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Marksman-Data/", "a", _net_request_listener);
					}
					else {
						if (getIntent().getStringExtra("category").equals("Mage")) {
							net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Mage-Data/", "a", _net_request_listener);
						}
						else {
							if (getIntent().getStringExtra("category").equals("Support")) {
								net.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Support-Data/", "a", _net_request_listener);
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _MoreBlocks() {
	}
	int BOTTOM = 3;
	int TOP = 1;
	int CENTER = 2;
	
	public void AlphaToast(Context context, String str, int i, int i2, int i3, int i4, int i5){
		Toast makeText = Toast.makeText(context,str, 0);
		        View view = makeText.getView();
		        TextView textView = (TextView) view.findViewById(16908299);
		        textView.setTextSize(i);
		        textView.setTextColor(i2);
		        textView.setGravity(i5);
		        GradientDrawable gradientDrawable = new GradientDrawable();
		        gradientDrawable.setColor(i3);
		        gradientDrawable.setCornerRadius(i4);
		        view.setBackgroundDrawable(gradientDrawable);
		        view.setPadding(15, 10, 15, 10);
		        view.setElevation(10.0f);
		
		        switch (i5) {
			            case 1:
			                makeText.setGravity(48, 0, 150);
			                break;
			            case 2:
			                makeText.setGravity(17, 0, 0);
			                break;
			            case 3:
			                makeText.setGravity(80, 0, 150);
			                break;
			        }
		        makeText.show();
	}
	{
	}
	
	
	public void _ActivityTransition(final View _view, final String _transitionName, final Intent _intent) {
		_view.setTransitionName(_transitionName); android.app.ActivityOptions optionsCompat = android.app.ActivityOptions.makeSceneTransitionAnimation(ListCategoryActivity.this, _view, _transitionName); startActivity(_intent, optionsCompat.toBundle());
	}
	
	
	public void _Progress(final boolean _ifShow) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.requestWindowFeature(Window.FEATURE_NO_TITLE);  prog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			prog.setMessage(null);
			prog.show();
			prog.setContentView(R.layout.loading);
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.list, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF121F2B);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear1.setBackground(SketchUiRD);
				linear1.setClickable(true);
			}
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("url").toString())).into(circleimageview1);
			textview1.setText(_data.get((int)_position).get("name").toString());
			if (listmap1.get((int)_position).containsKey("number")) {
				textview2.setText(_data.get((int)_position).get("number").toString().concat(" Available Skin's"));
			}
			else {
				if (listmap1.get((int)_position).containsKey("advanced")) {
					textview2.setText(_data.get((int)_position).get("advanced").toString());
				}
			}
			if (listmap1.get((int)_position).containsKey("New")) {
				if (_data.get((int)_position).get("New").toString().equals("Revamped")) {
					linear5.setBackgroundResource(R.drawable.revamped);
					textview3.setText("Revamped");
				}
				else {
					if (_data.get((int)_position).get("New").toString().equals("New Skin")) {
						linear5.setBackgroundResource(R.drawable.updated);
						textview3.setText("New skin");
					}
				}
			}
			else {
				linear5.setVisibility(View.GONE);
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						if (!textview2.getText().toString().equals("Advance Server")) {
							intent.putExtra("Category", getIntent().getStringExtra("category"));
							intent.putExtra("List", getIntent().getStringExtra("list"));
							intent.putExtra("name", _data.get((int)_position).get("name").toString());
							intent.putExtra("url", _data.get((int)_position).get("url").toString());
							intent.putExtra("number", _data.get((int)_position).get("number").toString());
							if (_data.get((int)_position).containsKey("backup")) {
								intent.putExtra("backup", _data.get((int)_position).get("backup").toString());
							}
							if (_data.get((int)_position).containsKey("landscape")) {
								intent.putExtra("landscape", _data.get((int)_position).get("landscape").toString());
							}
							if (_data.get((int)_position).containsKey("size1")) {
									intent.putExtra("size1", _data.get((int)_position).get("size1").toString());
							}
							if (_data.get((int)_position).containsKey("size2")) {
									intent.putExtra("size2", _data.get((int)_position).get("size2").toString());
							}
							if (_data.get((int)_position).containsKey("size3")) {
									intent.putExtra("size3", _data.get((int)_position).get("size3").toString());
							}
							if (_data.get((int)_position).containsKey("size4")) {
									intent.putExtra("size4", _data.get((int)_position).get("size4").toString());
							}
							if (_data.get((int)_position).containsKey("size5")) {
									intent.putExtra("size5", _data.get((int)_position).get("size5").toString());
							}
							if (_data.get((int)_position).containsKey("size6")) {
									intent.putExtra("size6", _data.get((int)_position).get("size6").toString());
							}
							if (_data.get((int)_position).containsKey("size7")) {
									intent.putExtra("size7", _data.get((int)_position).get("size7").toString());
							}
							if (_data.get((int)_position).containsKey("size8")) {
									intent.putExtra("size8", _data.get((int)_position).get("size8").toString());
							}
							if (_data.get((int)_position).containsKey("size9")) {
									intent.putExtra("size9", _data.get((int)_position).get("size9").toString());
							}
							if (_data.get((int)_position).containsKey("skin1")) {
									intent.putExtra("skin1", _data.get((int)_position).get("skin1").toString());
							}
							if (_data.get((int)_position).containsKey("skin2")) {
									intent.putExtra("skin2", _data.get((int)_position).get("skin2").toString());
							}
							if (_data.get((int)_position).containsKey("skin3")) {
									intent.putExtra("skin3", _data.get((int)_position).get("skin3").toString());
							}
							if (_data.get((int)_position).containsKey("skin4")) {
									intent.putExtra("skin4", _data.get((int)_position).get("skin4").toString());
							}
							if (_data.get((int)_position).containsKey("skin5")) {
									intent.putExtra("skin5", _data.get((int)_position).get("skin5").toString());
							}
							if (_data.get((int)_position).containsKey("skin6")) {
									intent.putExtra("skin6", _data.get((int)_position).get("skin6").toString());
							}
							if (_data.get((int)_position).containsKey("skin7")) {
									intent.putExtra("skin7", _data.get((int)_position).get("skin7").toString());
							}
							if (_data.get((int)_position).containsKey("skin8")) {
									intent.putExtra("skin8", _data.get((int)_position).get("skin8").toString());
							}
							if (_data.get((int)_position).containsKey("skin9")) {
									intent.putExtra("skin9", _data.get((int)_position).get("skin9").toString());
							}
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							intent.setRepeatCount((int)(_data));
							if (_data.get((int)_position).containsKey("logo1")) {
									intent.putExtra("logo1", _data.get((int)_position).get("logo1").toString());
							}
							if (_data.get((int)_position).containsKey("logo2")) {
									intent.putExtra("logo2", _data.get((int)_position).get("logo2").toString());
							}
							if (_data.get((int)_position).containsKey("logo3")) {
									intent.putExtra("logo3", _data.get((int)_position).get("logo3").toString());
							}
							if (_data.get((int)_position).containsKey("logo4")) {
									intent.putExtra("logo4", _data.get((int)_position).get("logo4").toString());
							}
							if (_data.get((int)_position).containsKey("logo5")) {
									intent.putExtra("logo5", _data.get((int)_position).get("logo5").toString());
							}
							if (_data.get((int)_position).containsKey("logo6")) {
									intent.putExtra("logo6", _data.get((int)_position).get("logo6").toString());
							}
							if (_data.get((int)_position).containsKey("logo7")) {
									intent.putExtra("logo7", _data.get((int)_position).get("logo7").toString());
							}
							if (_data.get((int)_position).containsKey("logo8")) {
									intent.putExtra("logo8", _data.get((int)_position).get("logo8").toString());
							}
							if (_data.get((int)_position).containsKey("logo9")) {
									intent.putExtra("logo9", _data.get((int)_position).get("logo9").toString());
							}
							intent.setClass(getApplicationContext(), ListskinAndroid11Activity.class);
							_ActivityTransition(circleimageview1, "p", intent);
						}
						else {
							AlphaToast(ListCategoryActivity.this,"This hero is available on advanced server",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
						}
					}
					else {
						AlphaToast(ListCategoryActivity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}