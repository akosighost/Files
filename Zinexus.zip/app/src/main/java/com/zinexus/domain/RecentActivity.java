package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.thekhaeng.pushdownanim.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class RecentActivity extends AppCompatActivity {
	
	private HashMap<String, Object> map1 = new HashMap<>();
	private String save = "";
	private double length = 0;
	private double number = 0;
	private String value1 = "";
	
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private ImageView imageview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private EditText edittext1;
	private JazzyListView listview1;
	
	private Intent intent = new Intent();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.recent);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		imageview2 = findViewById(R.id.imageview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		edittext1 = findViewById(R.id.edittext1);
		listview1 = findViewById(R.id.listview1);
		net = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_Progress(true);
				intent.setClass(getApplicationContext(), RefreshActivity.class);
				intent.putExtra("Category", getIntent().getStringExtra("Category"));
				intent.putExtra("List", getIntent().getStringExtra("List"));
				startActivity(intent);
				overridePendingTransition(R.anim.fin, R.anim.fout);
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				listmap1 = new Gson().fromJson(save, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				length = listmap1.size();
				number = length - 1;
				for(int _repeat17 = 0; _repeat17 < (int)(length); _repeat17++) {
					value1 = listmap1.get((int)number).get("Details").toString();
					if (!(_charSeq.length() > value1.length()) && value1.toLowerCase().contains(_charSeq.toLowerCase())) {
						
					}
					else {
						listmap1.remove((int)(number));
						listview1.setAdapter(new Listview1Adapter(listmap1));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					number--;
				}
				listview1.setAdapter(new Listview1Adapter(listmap1));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					
					     listmap1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					listview1.setAdapter(new Listview1Adapter(listmap1));
					((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					save = new Gson().toJson(listmap1);
					_Progress(false);
					
					      } catch (Exception e) {
					
					      
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				AlphaToast(RecentActivity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =RecentActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF0B141A);
		}
		android.graphics.drawable.GradientDrawable linear3gd = new android.graphics.drawable.GradientDrawable();
		
		linear3gd.setColor(0xFF121F2B);
		
		linear3gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear3gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		
		linear3.setBackground(linear3gd);
		
		linear3.setElevation(50);
		android.graphics.drawable.GradientDrawable linear12gd = new android.graphics.drawable.GradientDrawable();
		
		linear12gd.setColor(0xFF121F2B);
		
		linear12gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear12gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear12.setBackground(linear12gd);
		
		linear12.setElevation(50);
		android.graphics.drawable.GradientDrawable linear13gd = new android.graphics.drawable.GradientDrawable();
		
		linear13gd.setColor(0xFF121F2B);
		
		linear13gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear13gd.setCornerRadii(new float[]{(int)30,(int)30,(int)30,(int)30,(int)0,(int)0,(int)0,(int)0});
		
		linear13.setBackground(linear13gd);
		
		linear13.setElevation(50);
		edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 40)});
		edittext1.setCursorVisible(false);
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		OverScrollDecoratorHelper.setUpOverScroll(listview1);
	}
	
	@Override
	public void onBackPressed() {
		startActivity(new Intent(RecentActivity.this, HomeActivity.class)); Animatoo.animateFade(RecentActivity.this);
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		net.startRequestNetwork(RequestNetworkController.GET, "https://sheetdb.io/api/v1/mwd2azigurm64", "", _net_request_listener);
		_Progress(true);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		net.startRequestNetwork(RequestNetworkController.GET, "https://sheetdb.io/api/v1/mwd2azigurm64", "", _net_request_listener);
		_Progress(true);
	}
	public void _Progress(final boolean _ifShow) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.requestWindowFeature(Window.FEATURE_NO_TITLE);  prog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			prog.setMessage(null);
			prog.show();
			prog.setContentView(R.layout.loading);
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	public void _MoreBlocks() {
	}
	int BOTTOM = 3;
	int TOP = 1;
	int CENTER = 2;
	
	public void AlphaToast(Context context, String str, int i, int i2, int i3, int i4, int i5){
		Toast makeText = Toast.makeText(context,str, 0);
		        View view = makeText.getView();
		        TextView textView = (TextView) view.findViewById(16908299);
		        textView.setTextSize(i);
		        textView.setTextColor(i2);
		        textView.setGravity(i5);
		        GradientDrawable gradientDrawable = new GradientDrawable();
		        gradientDrawable.setColor(i3);
		        gradientDrawable.setCornerRadius(i4);
		        view.setBackgroundDrawable(gradientDrawable);
		        view.setPadding(15, 10, 15, 10);
		        view.setElevation(10.0f);
		
		        switch (i5) {
			            case 1:
			                makeText.setGravity(48, 0, 150);
			                break;
			            case 2:
			                makeText.setGravity(17, 0, 0);
			                break;
			            case 3:
			                makeText.setGravity(80, 0, 150);
			                break;
			        }
		        makeText.show();
	}
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.recent_list, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				SketchUi.setColor(0xFF121F2B);linear1.setBackground(SketchUi);
			}
			textview1.setText(_data.get((int)_position).get("Time").toString().concat(" ".concat(_data.get((int)_position).get("Date").toString())));
			textview2.setText(_data.get((int)_position).get("Details").toString());
			if (_data.get((int)_position).get("Accept").toString().equals("Pending")) {
				linear4.setBackgroundResource(R.drawable.pending);
				textview3.setText("Pending");
			}
			else {
				if (_data.get((int)_position).get("Accept").toString().equals("Updated")) {
					linear4.setBackgroundResource(R.drawable.updated);
					textview3.setText("Updated");
				}
				else {
					if (_data.get((int)_position).get("Accept").toString().equals("Revamped")) {
						linear4.setBackgroundResource(R.drawable.revamped);
						textview3.setText("Revamped");
					}
					else {
						if (_data.get((int)_position).get("Accept").toString().equals("Admin")) {
							linear4.setBackgroundResource(R.drawable.revamped);
							textview3.setText("Admin");
						}
						else {
							linear4.setBackgroundResource(R.drawable.red);
							textview3.setText("Failed");
						}
					}
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}