package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kaopiz.kprogresshud.*;
import com.thekhaeng.pushdownanim.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import me.everything.android.ui.overscroll.OverScrollDecoratorHelper;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> map_recyclerview1 = new HashMap<>();
	private boolean role = false;
	private boolean effect = false;
	
	private ArrayList<HashMap<String, Object>> listmap_recyclerview1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap_count = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap_viewpager1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap_update = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private ImageView imageview2;
	private ScrollView vscroll1;
	private LinearLayout linear10;
	private LinearLayout linear20;
	private RecyclerView recyclerview1;
	private LinearLayout linear18;
	private LinearLayout linear11;
	private LinearLayout linear22;
	private ViewPager viewpager1;
	private LinearLayout linear24;
	private LinearLayout linear26;
	private LinearLayout linear28;
	private LinearLayout linear21;
	private TextView textview10;
	private LinearLayout linear19;
	private TextView textview9;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private ImageView imageview3;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linear16;
	private ImageView imageview4;
	private TextView textview5;
	private TextView textview6;
	private LinearLayout linear17;
	private ImageView imageview5;
	private TextView textview7;
	private TextView textview8;
	private LinearLayout linear23;
	private TextView textview12;
	private LinearLayout linear25;
	private TextView textview11;
	private LinearLayout linear27;
	private TextView textview13;
	private LinearLayout linear29;
	private TextView textview14;
	
	private Intent intent = new Intent();
	private TimerTask timer;
	private RequestNetwork update;
	private RequestNetwork.RequestListener _update_request_listener;
	private RequestNetwork count;
	private RequestNetwork.RequestListener _count_request_listener;
	private SharedPreferences sp;
	
	private OnCompleteListener CloudMessaging_onCompleteListener;
	private RequestNetwork effects;
	private RequestNetwork.RequestListener _effects_request_listener;
	private AlertDialog CustomDialog;
	private com.google.android.material.bottomsheet.BottomSheetDialog BottomSheet;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		imageview2 = findViewById(R.id.imageview2);
		vscroll1 = findViewById(R.id.vscroll1);
		linear10 = findViewById(R.id.linear10);
		linear20 = findViewById(R.id.linear20);
		recyclerview1 = findViewById(R.id.recyclerview1);
		linear18 = findViewById(R.id.linear18);
		linear11 = findViewById(R.id.linear11);
		linear22 = findViewById(R.id.linear22);
		viewpager1 = findViewById(R.id.viewpager1);
		linear24 = findViewById(R.id.linear24);
		linear26 = findViewById(R.id.linear26);
		linear28 = findViewById(R.id.linear28);
		linear21 = findViewById(R.id.linear21);
		textview10 = findViewById(R.id.textview10);
		linear19 = findViewById(R.id.linear19);
		textview9 = findViewById(R.id.textview9);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		imageview3 = findViewById(R.id.imageview3);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		linear16 = findViewById(R.id.linear16);
		imageview4 = findViewById(R.id.imageview4);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		linear17 = findViewById(R.id.linear17);
		imageview5 = findViewById(R.id.imageview5);
		textview7 = findViewById(R.id.textview7);
		textview8 = findViewById(R.id.textview8);
		linear23 = findViewById(R.id.linear23);
		textview12 = findViewById(R.id.textview12);
		linear25 = findViewById(R.id.linear25);
		textview11 = findViewById(R.id.textview11);
		linear27 = findViewById(R.id.linear27);
		textview13 = findViewById(R.id.textview13);
		linear29 = findViewById(R.id.linear29);
		textview14 = findViewById(R.id.textview14);
		update = new RequestNetwork(this);
		count = new RequestNetwork(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		effects = new RequestNetwork(this);
		
		_update_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					
					     listmap_update = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					try { 
						android.content.pm.PackageManager pm = getApplicationContext().getPackageManager(); android.content.pm.PackageInfo pinfo = pm.getPackageInfo(getApplicationContext().getPackageName().toString(), 0); String your_version = pinfo.versionName;  
						if (!your_version.equals(listmap_update.get((int)0).get("version").toString())) {
							CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
							LayoutInflater CustomDialogLI = getLayoutInflater();
							View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.dialog, null);
							CustomDialog.setView(CustomDialogCV);
							CustomDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);  CustomDialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
							final ImageView i1 = (ImageView)
							CustomDialogCV.findViewById(R.id.imageview1);
							final TextView t1 = (TextView)
							CustomDialogCV.findViewById(R.id.textview1);
							final TextView t2 = (TextView)
							CustomDialogCV.findViewById(R.id.textview2);
							final TextView t3 = (TextView)
							CustomDialogCV.findViewById(R.id.textview3);
							final Button b1 = (Button)
							CustomDialogCV.findViewById(R.id.button1);
							final LinearLayout l1 = (LinearLayout)
							CustomDialogCV.findViewById(R.id.linear3);
							final LinearLayout l2 = (LinearLayout)
							CustomDialogCV.findViewById(R.id.linear2);
							android.graphics.drawable.GradientDrawable i1gd = new android.graphics.drawable.GradientDrawable();
							
							i1gd.setColor(0xFF2196F3);
							
							i1gd.setStroke((int)0, Color.TRANSPARENT);
							
							i1gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
							
							i1.setBackground(i1gd);
							
							i1.setElevation(5);
							{
								android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
								int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
								SketchUi.setColor(0xFF2196F3);
								SketchUi.setCornerRadius(d*160);
								android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
								b1.setBackground(SketchUiRD);
								b1.setClickable(true);
							}
							android.graphics.drawable.GradientDrawable l2gd = new android.graphics.drawable.GradientDrawable();
							
							l2gd.setColor(0xFF2196F3);
							
							l2gd.setStroke((int)0, Color.TRANSPARENT);
							
							l2gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
							
							l2.setBackground(l2gd);
							
							l2.setElevation(5);
							android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
							
							l1gd.setColor(0xFFFFFFFF);
							
							l1gd.setStroke((int)0, Color.TRANSPARENT);
							
							l1gd.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50});
							
							l1.setBackground(l1gd);
							
							l1.setElevation(5);
							i1.setElevation((float)0.3d);
							i1.setImageResource(R.drawable.update);
							t1.setText("Update Available");
							t2.setText("Hello user! you are using old version of Zinexus Domain, you need to update to the latest version in order to experience a total multifunctions.");
							t3.setText("Download size: ".concat(listmap_update.get((int)0).get("size").toString().concat(" MB")));
							b1.setText("Update Now");
							b1.setOnClickListener(new View.OnClickListener(){
								@Override
								public void onClick(View _view){
									intent.setAction(Intent.ACTION_VIEW);
									intent.setData(Uri.parse(listmap_update.get((int)0).get("link").toString()));
									startActivity(intent);
								}
							});
							 
							CustomDialog.setCancelable(false);
							CustomDialog.show();
						}
					} catch (android.content.pm.PackageManager.NameNotFoundException e) { e.printStackTrace(); }
					
					      } catch (Exception e) {
					
					      
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_count_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					
					     listmap_count = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					textview5.setText(listmap_count.get((int)0).get("count").toString());
					
					      } catch (Exception e) {
					
					      
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		CloudMessaging_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(CloudMessaging_onCompleteListener);
			}
		};
		
		_effects_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					
					     listmap_viewpager1 = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					viewpager1.setAdapter(new Viewpager1Adapter(listmap_viewpager1));
					((PagerAdapter)viewpager1.getAdapter()).notifyDataSetChanged();
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									textview11.setText(listmap_viewpager1.get((int)viewpager1.getCurrentItem()).get("txt1").toString());
									textview12.setText(listmap_viewpager1.get((int)viewpager1.getCurrentItem()).get("txt2").toString().concat(" Effects Available"));
								}
							});
						}
					};
					_timer.scheduleAtFixedRate(timer, (int)(0), (int)(100));
					
					      } catch (Exception e) {
					
					      
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =HomeActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF0B141A);
		}
		update.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Update-App/", "a", _update_request_listener);
		count.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Count-Skins/", "a", _count_request_listener);
		effects.startRequestNetwork(RequestNetworkController.GET, "https://akosighost.github.io/Home-ListView-Data/", "a", _effects_request_listener);
		android.graphics.drawable.GradientDrawable linear3gd = new android.graphics.drawable.GradientDrawable();
		
		linear3gd.setColor(0xFF121F2B);
		
		linear3gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear3gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		
		linear3.setBackground(linear3gd);
		
		linear3.setElevation(50);
		android.graphics.drawable.GradientDrawable linear12gd = new android.graphics.drawable.GradientDrawable();
		
		linear12gd.setColor(0xFF121F2B);
		
		linear12gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear12gd.setCornerRadii(new float[]{(int)20,(int)20,(int)0,(int)0,(int)0,(int)0,(int)20,(int)20});
		
		linear12.setBackground(linear12gd);
		
		linear12.setElevation(50);
		android.graphics.drawable.GradientDrawable linear13gd = new android.graphics.drawable.GradientDrawable();
		
		linear13gd.setColor(0xFF121F2B);
		
		linear13gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear13gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)0,(int)0,(int)0,(int)0});
		
		linear13.setBackground(linear13gd);
		
		linear13.setElevation(50);
		android.graphics.drawable.GradientDrawable linear14gd = new android.graphics.drawable.GradientDrawable();
		
		linear14gd.setColor(0xFF121F2B);
		
		linear14gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear14gd.setCornerRadii(new float[]{(int)0,(int)0,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
		
		linear14.setBackground(linear14gd);
		
		linear14.setElevation(50);
		android.graphics.drawable.GradientDrawable linear19gd = new android.graphics.drawable.GradientDrawable();
		
		linear19gd.setColor(0xFF121F2B);
		
		linear19gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear19gd.setCornerRadii(new float[]{(int)30,(int)30,(int)30,(int)30,(int)0,(int)0,(int)0,(int)0});
		
		linear19.setBackground(linear19gd);
		
		linear19.setElevation(50);
		android.graphics.drawable.GradientDrawable linear21gd = new android.graphics.drawable.GradientDrawable();
		
		linear21gd.setColor(0xFF121F2B);
		
		linear21gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear21gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear21.setBackground(linear21gd);
		
		linear21.setElevation(50);
		android.graphics.drawable.GradientDrawable linear23gd = new android.graphics.drawable.GradientDrawable();
		
		linear23gd.setColor(0xFF121F2B);
		
		linear23gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear23gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear23.setBackground(linear23gd);
		
		linear23.setElevation(50);
		android.graphics.drawable.GradientDrawable linear25gd = new android.graphics.drawable.GradientDrawable();
		
		linear25gd.setColor(0xFF121F2B);
		
		linear25gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear25gd.setCornerRadii(new float[]{(int)30,(int)30,(int)30,(int)30,(int)0,(int)0,(int)0,(int)0});
		
		linear25.setBackground(linear25gd);
		
		linear25.setElevation(50);
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF121F2B);
			SketchUi.setCornerRadius(d*10);
			linear27.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
			linear27.setBackground(SketchUiRD);
			linear27.setClickable(true);
		}
		android.graphics.drawable.GradientDrawable linear29gd = new android.graphics.drawable.GradientDrawable();
		
		linear29gd.setColor(0xFF121F2B);
		
		linear29gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear29gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear29.setBackground(linear29gd);
		
		linear29.setElevation(50);
		viewpager1.setPageTransformer(true, new AccordionTransformer());
		viewpager1.setHorizontalScrollBarEnabled(false);
		viewpager1.setVerticalScrollBarEnabled(false);
		viewpager1.setOverScrollMode(ViewPager.OVER_SCROLL_NEVER);
		vscroll1.setHorizontalScrollBarEnabled(false);
		vscroll1.setVerticalScrollBarEnabled(false);
		vscroll1.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
		OverScrollDecoratorHelper.setUpOverScroll(vscroll1);
		OverScrollDecoratorHelper.setUpOverScroll(viewpager1);
		_RecycleView1();
		_PushDown();
		role = true;
		_CategoryAnimation();
		effect = true;
		_EffectAnimation();
		if (sp.getString("tap", "").equals("")) {
			TapTargetView.showFor(HomeActivity.this,
			
			TapTarget.forView(imageview1, "Settings", "Click this if you don't know how to use this app")
			.outerCircleColorInt(Color.parseColor("#101010"))
			.outerCircleAlpha(0.99f)
			.targetCircleColor(android.R.color.white)
			.titleTextSize(16)
			.titleTextColor(android.R.color.white)
			.descriptionTextSize(15)
			.descriptionTextColor(android.R.color.white)
			.textColor(android.R.color.white)
			.textTypeface(Typeface.SANS_SERIF)
			.dimColor(android.R.color.black)
			.drawShadow(true)
			.cancelable(false)
			.tintTarget(true)
			.transparentTarget(true)
			.targetRadius(50),
			 new TapTargetView.Listener() {
				@Override
				public void onTargetClick(TapTargetView view) {
					super.onTargetClick(view);
					TapTargetView.showFor(HomeActivity.this,
					
					TapTarget.forView(imageview2, "Youtube", "Then click this button if you want to subscribe to my channel")
					.outerCircleColorInt(Color.parseColor("#101010"))
					.outerCircleAlpha(0.99f)
					.targetCircleColor(android.R.color.white)
					.titleTextSize(16)
					.titleTextColor(android.R.color.white)
					.descriptionTextSize(15)
					.descriptionTextColor(android.R.color.white)
					.textColor(android.R.color.white)
					.textTypeface(Typeface.SANS_SERIF)
					.dimColor(android.R.color.black)
					.drawShadow(true)
					.cancelable(false)
					.tintTarget(true)
					.transparentTarget(true)
					.targetRadius(50),
					 new TapTargetView.Listener() {
						@Override
						public void onTargetClick(TapTargetView view) {
							super.onTargetClick(view);
							TapTargetView.showFor(HomeActivity.this,
							
							TapTarget.forView(textview3, "Recent Updates", "New Features & Recent Request")
							.outerCircleColorInt(Color.parseColor("#101010"))
							.outerCircleAlpha(0.99f)
							.targetCircleColor(android.R.color.white)
							.titleTextSize(16)
							.titleTextColor(android.R.color.white)
							.descriptionTextSize(15)
							.descriptionTextColor(android.R.color.white)
							.textColor(android.R.color.white)
							.textTypeface(Typeface.SANS_SERIF)
							.dimColor(android.R.color.black)
							.drawShadow(true)
							.cancelable(false)
							.tintTarget(true)
							.transparentTarget(true)
							.targetRadius(50),
							 new TapTargetView.Listener() {
								@Override
								public void onTargetClick(TapTargetView view) {
									super.onTargetClick(view);
									TapTargetView.showFor(HomeActivity.this,
									
									TapTarget.forView(textview7, "Check for Updates", "Tap this if you want to check if there's an update")
									.outerCircleColorInt(Color.parseColor("#101010"))
									.outerCircleAlpha(0.99f)
									.targetCircleColor(android.R.color.white)
									.titleTextSize(16)
									.titleTextColor(android.R.color.white)
									.descriptionTextSize(15)
									.descriptionTextColor(android.R.color.white)
									.textColor(android.R.color.white)
									.textTypeface(Typeface.SANS_SERIF)
									.dimColor(android.R.color.black)
									.drawShadow(true)
									.cancelable(false)
									.tintTarget(true)
									.transparentTarget(true)
									.targetRadius(50),
									 new TapTargetView.Listener() {
										@Override
										public void onTargetClick(TapTargetView view) {
											super.onTargetClick(view);
											TapTargetView.showFor(HomeActivity.this,
											
											TapTarget.forView(linear27, "More Feature's", "Coming soon!")
											.outerCircleColorInt(Color.parseColor("#101010"))
											.outerCircleAlpha(0.99f)
											.targetCircleColor(android.R.color.white)
											.titleTextSize(16)
											.titleTextColor(android.R.color.white)
											.descriptionTextSize(15)
											.descriptionTextColor(android.R.color.white)
											.textColor(android.R.color.white)
											.textTypeface(Typeface.SANS_SERIF)
											.dimColor(android.R.color.black)
											.drawShadow(true)
											.cancelable(false)
											.tintTarget(true)
											.transparentTarget(true)
											.targetRadius(50),
											 new TapTargetView.Listener() {
												@Override
												public void onTargetClick(TapTargetView view) {
													super.onTargetClick(view);
													sp.edit().putString("tap", ".").commit();
												}
											});
										}
									});
								}
							});
						}
					});
				}
			});
		}
		else {
			
		}
	}
	
	
	@Override
	public void onBackPressed() {
		CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
		LayoutInflater CustomDialogLI = getLayoutInflater();
		View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.quit, null);
		CustomDialog.setView(CustomDialogCV);
		CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		final LinearLayout l1 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear1);
		final LinearLayout l6 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear6);
		final LinearLayout l7 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear7);
		android.graphics.drawable.GradientDrawable linear1gd = new android.graphics.drawable.GradientDrawable();
		
		linear1gd.setColor(0xFF0B141D);
		
		linear1gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear1gd.setCornerRadii(new float[]{(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8});
		
		linear1.setBackground(linear1gd);
		
		linear1.setElevation(50);
		l6.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				CustomDialog.dismiss();
			}
		});
		l7.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				finishAffinity();
			}
		});
		CustomDialog.setCancelable(false);
		CustomDialog.show();
	}
	
	@Override
	protected void onPostCreate(Bundle _savedInstanceState) {
		super.onPostCreate(_savedInstanceState);
		// onPostCreate()
		
	}static class UiUtil {
		    UiUtil() {
			    }
		    static int dp(Context context, int val) {
			        return (int) TypedValue.applyDimension(
			                TypedValue.COMPLEX_UNIT_DIP, val, context.getResources().getDisplayMetrics());
			    }
		    static int sp(Context context, int val) {
			        return (int) TypedValue.applyDimension(
			                TypedValue.COMPLEX_UNIT_SP, val, context.getResources().getDisplayMetrics());
			    }
		    static int themeIntAttr(Context context, String attr) {
			        final android.content.res.Resources.Theme theme = context.getTheme();
			        if (theme == null) {
				            return -1;
				        }
			        final TypedValue value = new TypedValue();
			        final int id = context.getResources().getIdentifier(attr, "attr", context.getPackageName());
			
			        if (id == 0) {
				            // Not found
				            return -1;
				        }
			        theme.resolveAttribute(id, value, true);
			        return value.data;
			    }
		    static int setAlpha(int argb, float alpha) {
			        if (alpha > 1.0f) {
				            alpha = 1.0f;
				        } else if (alpha <= 0.0f) {
				            alpha = 0.0f;
				        }
			        return ((int) ((argb >>> 24) * alpha) << 24) | (argb & 0x00FFFFFF);
			    }
	}
			static class FloatValueAnimatorBuilder {
		
		    private final ValueAnimator animator;
		
		    private EndListener endListener;
		
		    interface UpdateListener {
			        void onUpdate(float lerpTime);
			    }
		    interface EndListener {
			        void onEnd();
			    }
		    protected FloatValueAnimatorBuilder() {
			        this(false);
			    }
		    FloatValueAnimatorBuilder(boolean reverse) {
			        if (reverse) {
				            this.animator = ValueAnimator.ofFloat(1.0f, 0.0f);
				        } else {
				            this.animator = ValueAnimator.ofFloat(0.0f, 1.0f);
				        }
			    }
		    public FloatValueAnimatorBuilder delayBy(long millis) {
			        animator.setStartDelay(millis);
			        return this;
			    }
		    public FloatValueAnimatorBuilder duration(long millis) {
			        animator.setDuration(millis);
			        return this;
			    }
		    public FloatValueAnimatorBuilder interpolator(TimeInterpolator lerper) {
			        animator.setInterpolator(lerper);
			        return this;
			    }
		    public FloatValueAnimatorBuilder repeat(int times) {
			        animator.setRepeatCount(times);
			        return this;
			    }
		    public FloatValueAnimatorBuilder onUpdate(final UpdateListener listener) {
			        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
				            @Override
				            public void onAnimationUpdate(ValueAnimator animation) {
					                listener.onUpdate((float) animation.getAnimatedValue());
					            }
				        });
			        return this;
			    }
		    public FloatValueAnimatorBuilder onEnd(final EndListener listener) {
			        this.endListener = listener;
			        return this;
			    }
		    public ValueAnimator build() {
			        if (endListener != null) {
				            animator.addListener(new AnimatorListenerAdapter() {
					                @Override
					                public void onAnimationEnd(Animator animation) {
						                    endListener.onEnd();
						                }
					            });
				        }
			        return animator;
			    }
	}
			static class ReflectUtil {
		    ReflectUtil() {
			    }
		    static Object getPrivateField(Object source, String fieldName)
		            throws NoSuchFieldException, IllegalAccessException {
			        final java.lang.reflect.Field objectField = source.getClass().getDeclaredField(fieldName);
			        objectField.setAccessible(true);
			        return objectField.get(source);
			    }
	}
			static class TapTarget extends Activity {
		    final CharSequence title;
		    final CharSequence description;
		    float outerCircleAlpha = 0.96f;
		    int targetRadius = 44;
		    Rect bounds;
		    android.graphics.drawable.Drawable icon;
		    Typeface titleTypeface;
		    Typeface descriptionTypeface;
		
		
		    private int outerCircleColorRes = -1;
		    private int targetCircleColorRes = -1;
		    private int dimColorRes = -1;
		    private int titleTextColorRes = -1;
		    private int descriptionTextColorRes = -1;
		
		    private Integer outerCircleColor = null;
		    private Integer targetCircleColor = null;
		    private Integer dimColor = null;
		    private Integer titleTextColor = null;
		    private Integer descriptionTextColor = null;
		
		    private int titleTextDimen = -1;
		    private int descriptionTextDimen = -1;
		    private int titleTextSize = 20;
		    private int descriptionTextSize = 18;
		    int id = -1;
		    boolean drawShadow = false;
		    boolean cancelable = true;
		    boolean tintTarget = true;
		    boolean transparentTarget = false;
		    float descriptionTextAlpha = 0.54f;
		
		    public static TapTarget forView(View view, CharSequence title) {
			        return forView(view, title, null);
			    }
		    public static TapTarget forView(View view, CharSequence title, CharSequence description) {
			        return new ViewTapTarget(view, title, description);
			    }
		    public static TapTarget forBounds(Rect bounds, CharSequence title) {
			        return forBounds(bounds, title, null);
			    }
		    public static TapTarget forBounds(Rect bounds, CharSequence title,  CharSequence description) {
			        return new TapTarget(bounds, title, description);
			    }
		    protected TapTarget(Rect bounds, CharSequence title,  CharSequence description) {
			        this(title, description);
			        if (bounds == null) {
				            throw new IllegalArgumentException("Cannot pass null bounds or title");
				        }
			        this.bounds = bounds;
			    }
		    protected TapTarget(CharSequence title,  CharSequence description) {
			        if (title == null) {
				            throw new IllegalArgumentException("Cannot pass null title");
				        }
			        this.title = title;
			        this.description = description;
			    }
		    public TapTarget transparentTarget(boolean transparent) {
			        this.transparentTarget = transparent;
			        return this;
			    }
		    public TapTarget outerCircleColor( int color) {
			        this.outerCircleColorRes = color;
			        return this;
			    }
		    public TapTarget outerCircleColorInt( int color) {
			        this.outerCircleColor = color;
			        return this;
			    }
		    public TapTarget outerCircleAlpha(float alpha) {
			        if (alpha < 0.0f || alpha > 1.0f) {
				            throw new IllegalArgumentException("Given an invalid alpha value: " + alpha);
				        }
			        this.outerCircleAlpha = alpha;
			        return this;
			    }
		    public TapTarget targetCircleColor( int color) {
			        this.targetCircleColorRes = color;
			        return this;
			    }
		    public TapTarget targetCircleColorInt( int color) {
			        this.targetCircleColor = color;
			        return this;
			    }
		    public TapTarget textColor( int color) {
			        this.titleTextColorRes = color;
			        this.descriptionTextColorRes = color;
			        return this;
			    }
		    public TapTarget textColorInt( int color) {
			        this.titleTextColor = color;
			        this.descriptionTextColor = color;
			        return this;
			    }
		    public TapTarget titleTextColor( int color) {
			        this.titleTextColorRes = color;
			        return this;
			    }
		    public TapTarget titleTextColorInt( int color) {
			        this.titleTextColor = color;
			        return this;
			    }
		    public TapTarget descriptionTextColor( int color) {
			        this.descriptionTextColorRes = color;
			        return this;
			    }
		    public TapTarget descriptionTextColorInt( int color) {
			        this.descriptionTextColor = color;
			        return this;
			    }
		    public TapTarget textTypeface(Typeface typeface) {
			        if (typeface == null) throw new IllegalArgumentException("Cannot use a null typeface");
			        titleTypeface = typeface;
			        descriptionTypeface = typeface;
			        return this;
			    }
		    public TapTarget titleTypeface(Typeface titleTypeface) {
			        if (titleTypeface == null) throw new IllegalArgumentException("Cannot use a null typeface");
			        this.titleTypeface = titleTypeface;
			        return this;
			    }
		    public TapTarget descriptionTypeface(Typeface descriptionTypeface) {
			        if (descriptionTypeface == null) throw new IllegalArgumentException("Cannot use a null typeface");
			        this.descriptionTypeface = descriptionTypeface;
			        return this;
			    }
		    public TapTarget titleTextSize(int sp) {
			        if (sp < 0) throw new IllegalArgumentException("Given negative text size");
			        this.titleTextSize = sp;
			        return this;
			    }
		    public TapTarget descriptionTextSize(int sp) {
			        if (sp < 0) throw new IllegalArgumentException("Given negative text size");
			        this.descriptionTextSize = sp;
			        return this;
			    }
		    public TapTarget titleTextDimen( int dimen) {
			        this.titleTextDimen = dimen;
			        return this;
			    }
		    public TapTarget descriptionTextAlpha(float descriptionTextAlpha) {
			        if (descriptionTextAlpha < 0 || descriptionTextAlpha > 1f) {
				            throw new IllegalArgumentException("Given an invalid alpha value: " + descriptionTextAlpha);
				        }
			        this.descriptionTextAlpha = descriptionTextAlpha;
			        return this;
			    }
		    public TapTarget descriptionTextDimen( int dimen) {
			        this.descriptionTextDimen = dimen;
			        return this;
			    }
		    public TapTarget dimColor( int color) {
			        this.dimColorRes = color;
			        return this;
			    }
		    public TapTarget dimColorInt( int color) {
			        this.dimColor = color;
			        return this;
			    }
		    public TapTarget drawShadow(boolean draw) {
			        this.drawShadow = draw;
			        return this;
			    }
		    public TapTarget cancelable(boolean status) {
			        this.cancelable = status;
			        return this;
			    }
		    public TapTarget tintTarget(boolean tint) {
			        this.tintTarget = tint;
			        return this;
			    }
		    public TapTarget icon(android.graphics.drawable.Drawable icon) {
			        return icon(icon, false);
			    }
		    public TapTarget icon(android.graphics.drawable.Drawable icon, boolean hasSetBounds) {
			        if (icon == null) throw new IllegalArgumentException("Cannot use null drawable");
			        this.icon = icon;
			        if (!hasSetBounds) {
				            this.icon.setBounds(new Rect(0, 0, this.icon.getIntrinsicWidth(), this.icon.getIntrinsicHeight()));
				        }
			        return this;
			    }
		    public TapTarget id(int id) {
			        this.id = id;
			        return this;
			    }
		    public TapTarget targetRadius(int targetRadius) {
			        this.targetRadius = targetRadius;
			        return this;
			    }
		    public int id() {
			        return id;
			    }
		    public void onReady(Runnable runnable) {
			        runnable.run();
			    }
		    public Rect bounds() {
			        if (bounds == null) {
				            throw new IllegalStateException("Requesting bounds that are not set! Make sure your target is ready");
				        }
			        return bounds;
			    }
		    Integer outerCircleColorInt(Context context) {
			        return colorResOrInt(context, outerCircleColor, outerCircleColorRes);
			    }
		    Integer targetCircleColorInt(Context context) {
			        return colorResOrInt(context, targetCircleColor, targetCircleColorRes);
			    }
		    Integer dimColorInt(Context context) {
			        return colorResOrInt(context, dimColor, dimColorRes);
			    }
		    Integer titleTextColorInt(Context context) {
			        return colorResOrInt(context, titleTextColor, titleTextColorRes);
			    }
		
		    Integer descriptionTextColorInt(Context context) {
			        return colorResOrInt(context, descriptionTextColor, descriptionTextColorRes);
			    }
		    int titleTextSizePx(Context context) {
			        return dimenOrSize(context, titleTextSize, titleTextDimen);
			    }
		    int descriptionTextSizePx(Context context) {
			        return dimenOrSize(context, descriptionTextSize, descriptionTextDimen);
			    }
		
		    private Integer colorResOrInt(Context context, Integer value,  int resource) {
			        if (resource != -1) {
				            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
					                return context.getColor(resource);
					            }
				        }
			        return value;
			    }
		    private int dimenOrSize(Context context, int size,  int dimen) {
			        if (dimen != -1) {
				            return context.getResources().getDimensionPixelSize(dimen);
				        }
			        return UiUtil.sp(context, size);
			    }
	}
			static class TapTargetView extends View {
		    private boolean isDismissed = false;
		    private boolean isDismissing = false;
		    private boolean isInteractable = true;
		
		    final int TARGET_PADDING;
		    final int TARGET_RADIUS;
		    final int TARGET_PULSE_RADIUS;
		    final int TEXT_PADDING;
		    final int TEXT_SPACING;
		    final int TEXT_MAX_WIDTH;
		    final int TEXT_POSITIONING_BIAS;
		    final int CIRCLE_PADDING;
		    final int GUTTER_DIM;
		    final int SHADOW_DIM;
		    final int SHADOW_JITTER_DIM;
		
		
		    final ViewGroup boundingParent;
		    final ViewManager parent;
		    final TapTarget target;
		    final Rect targetBounds;
		
		    final TextPaint titlePaint;
		    final TextPaint descriptionPaint;
		    final Paint outerCirclePaint;
		    final Paint outerCircleShadowPaint;
		    final Paint targetCirclePaint;
		    final Paint targetCirclePulsePaint;
		
		    CharSequence title;
		
		    StaticLayout titleLayout;
		
		    CharSequence description;
		
		    StaticLayout descriptionLayout;
		    boolean isDark;
		    boolean debug;
		    boolean shouldTintTarget;
		    boolean shouldDrawShadow;
		    boolean cancelable;
		    boolean visible;
		
		    // Debug related variables
		
		    SpannableStringBuilder debugStringBuilder;
		
		    DynamicLayout debugLayout;
		
		    TextPaint debugTextPaint;
		
		    Paint debugPaint;
		
		    // Drawing properties
		    Rect drawingBounds;
		    Rect textBounds;
		
		    Path outerCirclePath;
		    float outerCircleRadius;
		    int calculatedOuterCircleRadius;
		    int[] outerCircleCenter;
		    int outerCircleAlpha;
		
		    float targetCirclePulseRadius;
		    int targetCirclePulseAlpha;
		
		    float targetCircleRadius;
		    int targetCircleAlpha;
		
		    int textAlpha;
		    int dimColor;
		
		    float lastTouchX;
		    float lastTouchY;
		
		    int topBoundary;
		    int bottomBoundary;
		
		    Bitmap tintedTarget;
		
		    Listener listener;
		
		
		    ViewOutlineProvider outlineProvider;
		
		    public static TapTargetView showFor(Activity activity, TapTarget target) {
			        return showFor(activity, target, null);
			    }
		
		    public static TapTargetView showFor(Activity activity, TapTarget target, Listener listener) {
			        if (activity == null) throw new IllegalArgumentException("Activity is null");
			
			        final ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
			        final ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(
			                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
			        final ViewGroup content = (ViewGroup) decor.findViewById(android.R.id.content);
			        final TapTargetView tapTargetView = new TapTargetView(activity, decor, content, target, listener);
			        decor.addView(tapTargetView, layoutParams);
			
			        return tapTargetView;
			    }
		
		    public static TapTargetView showFor(Dialog dialog, TapTarget target) {
			        return showFor(dialog, target, null);
			    }
		
		    public static TapTargetView showFor(Dialog dialog, TapTarget target, Listener listener) {
			        if (dialog == null) throw new IllegalArgumentException("Dialog is null");
			
			        final Context context = dialog.getContext();
			        final WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
			        final WindowManager.LayoutParams params = new WindowManager.LayoutParams();
			        params.type = WindowManager.LayoutParams.TYPE_APPLICATION;
			        params.format = PixelFormat.RGBA_8888;
			        params.flags = 0;
			        params.gravity = Gravity.START | Gravity.TOP;
			        params.x = 0;
			        params.y = 0;
			        params.width = WindowManager.LayoutParams.MATCH_PARENT;
			        params.height = WindowManager.LayoutParams.MATCH_PARENT;
			
			        final TapTargetView tapTargetView = new TapTargetView(context, windowManager, null, target, listener);
			        windowManager.addView(tapTargetView, params);
			
			        return tapTargetView;
			    }
		
		    public static class Listener {
			        /** Signals that the user has clicked inside of the target **/
			        public void onTargetClick(TapTargetView view) {
				            view.dismiss(true);
				        }
			
			        /** Signals that the user has long clicked inside of the target **/
			        public void onTargetLongClick(TapTargetView view) {
				            onTargetClick(view);
				        }
			
			        /** If cancelable, signals that the user has clicked outside of the outer circle **/
			        public void onTargetCancel(TapTargetView view) {
				            view.dismiss(false);
				        }
			
			        /** Signals that the user clicked on the outer circle portion of the tap target **/
			        public void onOuterCircleClick(TapTargetView view) {
				            // no-op as default
				        }
			
			        /**
         * Signals that the tap target has been dismissed
         * @param userInitiated Whether the user caused this action
         *
         *
         */
			        public void onTargetDismissed(TapTargetView view, boolean userInitiated) {
				        }
			    }
		
		    final FloatValueAnimatorBuilder.UpdateListener expandContractUpdateListener = new FloatValueAnimatorBuilder.UpdateListener() {
			        @Override
			        public void onUpdate(float lerpTime) {
				            final float newOuterCircleRadius = calculatedOuterCircleRadius * lerpTime;
				            final boolean expanding = newOuterCircleRadius > outerCircleRadius;
				            if (!expanding) {
					                // When contracting we need to invalidate the old drawing bounds. Otherwise
					                // you will see artifacts as the circle gets smaller
					                calculateDrawingBounds();
					            }
				
				            final float targetAlpha = target.outerCircleAlpha * 255;
				            outerCircleRadius = newOuterCircleRadius;
				            outerCircleAlpha = (int) Math.min(targetAlpha, (lerpTime * 1.5f * targetAlpha));
				            outerCirclePath.reset();
				            outerCirclePath.addCircle(outerCircleCenter[0], outerCircleCenter[1], outerCircleRadius, Path.Direction.CW);
				
				            targetCircleAlpha = (int) Math.min(255.0f, (lerpTime * 1.5f * 255.0f));
				
				            if (expanding) {
					                targetCircleRadius = TARGET_RADIUS * Math.min(1.0f, lerpTime * 1.5f);
					            } else {
					                targetCircleRadius = TARGET_RADIUS * lerpTime;
					                targetCirclePulseRadius *= lerpTime;
					            }
				
				            textAlpha = (int) (delayedLerp(lerpTime, 0.7f) * 255);
				
				            if (expanding) {
					                calculateDrawingBounds();
					            }
				
				            invalidateViewAndOutline(drawingBounds);
				        }
			    };
		
		    final ValueAnimator expandAnimation = new FloatValueAnimatorBuilder()
		            .duration(250)
		            .delayBy(250)
		            .interpolator(new AccelerateDecelerateInterpolator())
		            .onUpdate(new FloatValueAnimatorBuilder.UpdateListener() {
			                @Override
			                public void onUpdate(float lerpTime) {
				                    expandContractUpdateListener.onUpdate(lerpTime);
				                }
			            })
		            .onEnd(new FloatValueAnimatorBuilder.EndListener() {
			                @Override
			                public void onEnd() {
				                    pulseAnimation.start();
				                    isInteractable = true;
				                }
			            })
		            .build();
		
		    final ValueAnimator pulseAnimation = new FloatValueAnimatorBuilder()
		            .duration(1000)
		            .repeat(ValueAnimator.INFINITE)
		            .interpolator(new AccelerateDecelerateInterpolator())
		            .onUpdate(new FloatValueAnimatorBuilder.UpdateListener() {
			                @Override
			                public void onUpdate(float lerpTime) {
				                    final float pulseLerp = delayedLerp(lerpTime, 0.5f);
				                    targetCirclePulseRadius = (1.0f + pulseLerp) * TARGET_RADIUS;
				                    targetCirclePulseAlpha = (int) ((1.0f - pulseLerp) * 255);
				                    targetCircleRadius = TARGET_RADIUS + halfwayLerp(lerpTime) * TARGET_PULSE_RADIUS;
				
				                    if (outerCircleRadius != calculatedOuterCircleRadius) {
					                        outerCircleRadius = calculatedOuterCircleRadius;
					                    }
				
				                    calculateDrawingBounds();
				                    invalidateViewAndOutline(drawingBounds);
				                }
			            })
		            .build();
		
		    final ValueAnimator dismissAnimation = new FloatValueAnimatorBuilder(true)
		            .duration(250)
		            .interpolator(new AccelerateDecelerateInterpolator())
		            .onUpdate(new FloatValueAnimatorBuilder.UpdateListener() {
			                @Override
			                public void onUpdate(float lerpTime) {
				                    expandContractUpdateListener.onUpdate(lerpTime);
				                }
			            })
		            .onEnd(new FloatValueAnimatorBuilder.EndListener() {
			                @Override
			                public void onEnd() {
				                    onDismiss(true);
				                    ViewUtil.removeView(parent, TapTargetView.this);
				                }
			            })
		            .build();
		
		    private final ValueAnimator dismissConfirmAnimation = new FloatValueAnimatorBuilder()
		            .duration(250)
		            .interpolator(new AccelerateDecelerateInterpolator())
		            .onUpdate(new FloatValueAnimatorBuilder.UpdateListener() {
			                @Override
			                public void onUpdate(float lerpTime) {
				                    final float spedUpLerp = Math.min(1.0f, lerpTime * 2.0f);
				                    outerCircleRadius = calculatedOuterCircleRadius * (1.0f + (spedUpLerp * 0.2f));
				                    outerCircleAlpha = (int) ((1.0f - spedUpLerp) * target.outerCircleAlpha * 255.0f);
				                    outerCirclePath.reset();
				                    outerCirclePath.addCircle(outerCircleCenter[0], outerCircleCenter[1], outerCircleRadius, Path.Direction.CW);
				                    targetCircleRadius = (1.0f - lerpTime) * TARGET_RADIUS;
				                    targetCircleAlpha = (int) ((1.0f - lerpTime) * 255.0f);
				                    targetCirclePulseRadius = (1.0f + lerpTime) * TARGET_RADIUS;
				                    targetCirclePulseAlpha = (int) ((1.0f - lerpTime) * targetCirclePulseAlpha);
				                    textAlpha = (int) ((1.0f - spedUpLerp) * 255.0f);
				                    calculateDrawingBounds();
				                    invalidateViewAndOutline(drawingBounds);
				                }
			            })
		            .onEnd(new FloatValueAnimatorBuilder.EndListener() {
			                @Override
			                public void onEnd() {
				                    onDismiss(true);
				                    ViewUtil.removeView(parent, TapTargetView.this);
				                }
			            })
		            .build();
		
		    private ValueAnimator[] animators = new ValueAnimator[]
		            {expandAnimation, pulseAnimation, dismissConfirmAnimation, dismissAnimation};
		
		    private final ViewTreeObserver.OnGlobalLayoutListener globalLayoutListener;
		    public TapTargetView(final Context context,
		                         final ViewManager parent,
		                          final ViewGroup boundingParent,
		                         final TapTarget target,
		                          final Listener userListener) {
			        super(context);
			        if (target == null) throw new IllegalArgumentException("Target cannot be null");
			
			        this.target = target;
			        this.parent = parent;
			        this.boundingParent = boundingParent;
			        this.listener = userListener != null ? userListener : new Listener();
			        this.title = target.title;
			        this.description = target.description;
			
			        TARGET_PADDING = UiUtil.dp(context, 20);
			        CIRCLE_PADDING = UiUtil.dp(context, 40);
			        TARGET_RADIUS = UiUtil.dp(context, target.targetRadius);
			        TEXT_PADDING = UiUtil.dp(context, 40);
			        TEXT_SPACING = UiUtil.dp(context, 8);
			        TEXT_MAX_WIDTH = UiUtil.dp(context, 360);
			        TEXT_POSITIONING_BIAS = UiUtil.dp(context, 20);
			        GUTTER_DIM = UiUtil.dp(context, 88);
			        SHADOW_DIM = UiUtil.dp(context, 8);
			        SHADOW_JITTER_DIM = UiUtil.dp(context, 1);
			        TARGET_PULSE_RADIUS = (int) (0.1f * TARGET_RADIUS);
			
			        outerCirclePath = new Path();
			        targetBounds = new Rect();
			        drawingBounds = new Rect();
			
			        titlePaint = new TextPaint();
			        titlePaint.setTextSize(target.titleTextSizePx(context));
			        titlePaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
			        titlePaint.setAntiAlias(true);
			
			        descriptionPaint = new TextPaint();
			        descriptionPaint.setTextSize(target.descriptionTextSizePx(context));
			        descriptionPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
			        descriptionPaint.setAntiAlias(true);
			        descriptionPaint.setAlpha((int) (0.54f * 255.0f));
			
			        outerCirclePaint = new Paint();
			        outerCirclePaint.setAntiAlias(true);
			        outerCirclePaint.setAlpha((int) (target.outerCircleAlpha * 255.0f));
			
			        outerCircleShadowPaint = new Paint();
			        outerCircleShadowPaint.setAntiAlias(true);
			        outerCircleShadowPaint.setAlpha(50);
			        outerCircleShadowPaint.setStyle(Paint.Style.STROKE);
			        outerCircleShadowPaint.setStrokeWidth(SHADOW_JITTER_DIM);
			        outerCircleShadowPaint.setColor(Color.BLACK);
			
			        targetCirclePaint = new Paint();
			        targetCirclePaint.setAntiAlias(true);
			
			        targetCirclePulsePaint = new Paint();
			        targetCirclePulsePaint.setAntiAlias(true);
			
			        applyTargetOptions(context);
			
			        globalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
				            @Override
				            public void onGlobalLayout() {
					                if (isDismissing) {
						                    return;
						                }
					                updateTextLayouts();
					                target.onReady(new Runnable() {
						                    @Override
						                    public void run() {
							                        final int[] offset = new int[2];
							
							                        targetBounds.set(target.bounds());
							
							                        getLocationOnScreen(offset);
							                        targetBounds.offset(-offset[0], -offset[1]);
							
							                        if (boundingParent != null) {
								                            final WindowManager windowManager
								                                    = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
								                            final DisplayMetrics displayMetrics = new DisplayMetrics();
								                            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
								
								                            final Rect rect = new Rect();
								                            boundingParent.getWindowVisibleDisplayFrame(rect);
								
								                            // We bound the boundaries to be within the screen's coordinates to
								                            // handle the case where the layout bounds do not match
								                            // (like when FLAG_LAYOUT_NO_LIMITS is specified)
								                            topBoundary = Math.max(0, rect.top);
								                            bottomBoundary = Math.min(rect.bottom, displayMetrics.heightPixels);
								                        }
							
							                        drawTintedTarget();
							                        requestFocus();
							                        calculateDimensions();
							
							                        startExpandAnimation();
							                    }
						                });
					            }
				        };
			
			        getViewTreeObserver().addOnGlobalLayoutListener(globalLayoutListener);
			
			        setFocusableInTouchMode(true);
			        setClickable(true);
			        setOnClickListener(new OnClickListener() {
				            @Override
				            public void onClick(View v) {
					                if (listener == null || outerCircleCenter == null || !isInteractable) return;
					
					                final boolean clickedInTarget =
					                        distance(targetBounds.centerX(), targetBounds.centerY(), (int) lastTouchX, (int) lastTouchY) <= targetCircleRadius;
					                final double distanceToOuterCircleCenter = distance(outerCircleCenter[0], outerCircleCenter[1],
					                        (int) lastTouchX, (int) lastTouchY);
					                final boolean clickedInsideOfOuterCircle = distanceToOuterCircleCenter <= outerCircleRadius;
					
					                if (clickedInTarget) {
						                    isInteractable = false;
						                    listener.onTargetClick(TapTargetView.this);
						                } else if (clickedInsideOfOuterCircle) {
						                    listener.onOuterCircleClick(TapTargetView.this);
						                } else if (cancelable) {
						                    isInteractable = false;
						                    listener.onTargetCancel(TapTargetView.this);
						                }
					            }
				        });
			
			        setOnLongClickListener(new OnLongClickListener() {
				            @Override
				            public boolean onLongClick(View v) {
					                if (listener == null) return false;
					
					                if (targetBounds.contains((int) lastTouchX, (int) lastTouchY)) {
						                    listener.onTargetLongClick(TapTargetView.this);
						                    return true;
						                }
					
					                return false;
					            }
				        });
			    }
		
		    private void startExpandAnimation() {
			        if (!visible) {
				            isInteractable = false;
				            expandAnimation.start();
				            visible = true;
				        }
			    }
		
		    protected void applyTargetOptions(Context context) {
			        shouldTintTarget = target.tintTarget;
			        shouldDrawShadow = target.drawShadow;
			        cancelable = target.cancelable;
			
			        // We can't clip out portions of a view outline, so if the user specified a transparent
			        // target, we need to fallback to drawing a jittered shadow approximation
			        if (shouldDrawShadow && Build.VERSION.SDK_INT >= 21 && !target.transparentTarget) {
				            outlineProvider = new ViewOutlineProvider() {
					                @Override
					                public void getOutline(View view, Outline outline) {
						                    if (outerCircleCenter == null) return;
						                    outline.setOval(
						                            (int) (outerCircleCenter[0] - outerCircleRadius), (int) (outerCircleCenter[1] - outerCircleRadius),
						                            (int) (outerCircleCenter[0] + outerCircleRadius), (int) (outerCircleCenter[1] + outerCircleRadius));
						                    outline.setAlpha(outerCircleAlpha / 255.0f);
						                    if (Build.VERSION.SDK_INT >= 22) {
							                        outline.offset(0, SHADOW_DIM);
							                    }
						                }
					            };
				
				            setOutlineProvider(outlineProvider);
				            setElevation(SHADOW_DIM);
				        }
			
			        if (shouldDrawShadow && outlineProvider == null && Build.VERSION.SDK_INT < 18) {
				            setLayerType(LAYER_TYPE_SOFTWARE, null);
				        } else {
				            setLayerType(LAYER_TYPE_HARDWARE, null);
				        }
			
			        final android.content.res.Resources.Theme theme = context.getTheme();
			        isDark = UiUtil.themeIntAttr(context, "isLightTheme") == 0;
			
			        final Integer outerCircleColor = target.outerCircleColorInt(context);
			        if (outerCircleColor != null) {
				            outerCirclePaint.setColor(outerCircleColor);
				        } else if (theme != null) {
				            outerCirclePaint.setColor(UiUtil.themeIntAttr(context, "colorPrimary"));
				        } else {
				            outerCirclePaint.setColor(Color.WHITE);
				        }
			
			        final Integer targetCircleColor = target.targetCircleColorInt(context);
			        if (targetCircleColor != null) {
				            targetCirclePaint.setColor(targetCircleColor);
				        } else {
				            targetCirclePaint.setColor(isDark ? Color.BLACK : Color.WHITE);
				        }
			
			        if (target.transparentTarget) {
				            targetCirclePaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
				        }
			
			        targetCirclePulsePaint.setColor(targetCirclePaint.getColor());
			
			        final Integer targetDimColor = target.dimColorInt(context);
			        if (targetDimColor != null) {
				            dimColor = UiUtil.setAlpha(targetDimColor, 0.3f);
				        } else {
				            dimColor = -1;
				        }
			
			        final Integer titleTextColor = target.titleTextColorInt(context);
			        if (titleTextColor != null) {
				            titlePaint.setColor(titleTextColor);
				        } else {
				            titlePaint.setColor(isDark ? Color.BLACK : Color.WHITE);
				        }
			
			        final Integer descriptionTextColor = target.descriptionTextColorInt(context);
			        if (descriptionTextColor != null) {
				            descriptionPaint.setColor(descriptionTextColor);
				        } else {
				            descriptionPaint.setColor(titlePaint.getColor());
				        }
			
			        if (target.titleTypeface != null) {
				            titlePaint.setTypeface(target.titleTypeface);
				        }
			
			        if (target.descriptionTypeface != null) {
				            descriptionPaint.setTypeface(target.descriptionTypeface);
				        }
			    }
		
		    @Override
		    protected void onDetachedFromWindow() {
			        super.onDetachedFromWindow();
			        onDismiss(false);
			    }
		
		    void onDismiss(boolean userInitiated) {
			        if (isDismissed) return;
			
			        isDismissing = false;
			        isDismissed = true;
			
			        for (final ValueAnimator animator : animators) {
				            animator.cancel();
				            animator.removeAllUpdateListeners();
				        }
			        ViewUtil.removeOnGlobalLayoutListener(getViewTreeObserver(), globalLayoutListener);
			        visible = false;
			
			        if (listener != null) {
				            listener.onTargetDismissed(this, userInitiated);
				        }
			    }
		
		    @Override
		    protected void onDraw(Canvas c) {
			        if (isDismissed || outerCircleCenter == null) return;
			
			        if (topBoundary > 0 && bottomBoundary > 0) {
				            c.clipRect(0, topBoundary, getWidth(), bottomBoundary);
				        }
			
			        if (dimColor != -1) {
				            c.drawColor(dimColor);
				        }
			
			        int saveCount;
			        outerCirclePaint.setAlpha(outerCircleAlpha);
			        if (shouldDrawShadow && outlineProvider == null) {
				            saveCount = c.save();
				            {
					                c.clipPath(outerCirclePath, Region.Op.DIFFERENCE);
					                drawJitteredShadow(c);
					            }
				            c.restoreToCount(saveCount);
				        }
			        c.drawCircle(outerCircleCenter[0], outerCircleCenter[1], outerCircleRadius, outerCirclePaint);
			
			        targetCirclePaint.setAlpha(targetCircleAlpha);
			        if (targetCirclePulseAlpha > 0) {
				            targetCirclePulsePaint.setAlpha(targetCirclePulseAlpha);
				            c.drawCircle(targetBounds.centerX(), targetBounds.centerY(),
				                    targetCirclePulseRadius, targetCirclePulsePaint);
				        }
			        c.drawCircle(targetBounds.centerX(), targetBounds.centerY(),
			                targetCircleRadius, targetCirclePaint);
			
			        saveCount = c.save();
			        {
				            c.translate(textBounds.left, textBounds.top);
				            titlePaint.setAlpha(textAlpha);
				            if (titleLayout != null) {
					                titleLayout.draw(c);
					            }
				
				            if (descriptionLayout != null && titleLayout != null) {
					                c.translate(0, titleLayout.getHeight() + TEXT_SPACING);
					                descriptionPaint.setAlpha((int) (target.descriptionTextAlpha * textAlpha));
					                descriptionLayout.draw(c);
					            }
				        }
			        c.restoreToCount(saveCount);
			
			        saveCount = c.save();
			        {
				            if (tintedTarget != null) {
					                c.translate(targetBounds.centerX() - tintedTarget.getWidth() / 2,
					                        targetBounds.centerY() - tintedTarget.getHeight() / 2);
					                c.drawBitmap(tintedTarget, 0, 0, targetCirclePaint);
					            } else if (target.icon != null) {
					                c.translate(targetBounds.centerX() - target.icon.getBounds().width() / 2,
					                        targetBounds.centerY() - target.icon.getBounds().height() / 2);
					                target.icon.setAlpha(targetCirclePaint.getAlpha());
					                target.icon.draw(c);
					            }
				        }
			        c.restoreToCount(saveCount);
			
			        if (debug) {
				            drawDebugInformation(c);
				        }
			    }
		
		    @Override
		    public boolean onTouchEvent(MotionEvent e) {
			        lastTouchX = e.getX();
			        lastTouchY = e.getY();
			        return super.onTouchEvent(e);
			    }
		
		    @Override
		    public boolean onKeyDown(int keyCode, KeyEvent event) {
			        if (isVisible() && cancelable && keyCode == KeyEvent.KEYCODE_BACK) {
				            event.startTracking();
				            return true;
				        }
			
			        return false;
			    }
		
		    @Override
		    public boolean onKeyUp(int keyCode, KeyEvent event) {
			        if (isVisible() && isInteractable && cancelable
			                && keyCode == KeyEvent.KEYCODE_BACK && event.isTracking() && !event.isCanceled()) {
				            isInteractable = false;
				
				            if (listener != null) {
					                listener.onTargetCancel(this);
					            } else {
					                new Listener().onTargetCancel(this);
					            }
				
				            return true;
				        }
			
			        return false;
			    }
		
		    /**
     * Dismiss this view
     * @param tappedTarget If the user tapped the target or not
     *                     (results in different dismiss animations)
     */
		    public void dismiss(boolean tappedTarget) {
			        isDismissing = true;
			        pulseAnimation.cancel();
			        expandAnimation.cancel();
			        if (tappedTarget) {
				            dismissConfirmAnimation.start();
				        } else {
				            dismissAnimation.start();
				        }
			    }
		
		    /** Specify whether to draw a wireframe around the view, useful for debugging **/
		    public void setDrawDebug(boolean status) {
			        if (debug != status) {
				            debug = status;
				            postInvalidate();
				        }
			    }
		
		    /** Returns whether this view is visible or not **/
		    public boolean isVisible() {
			        return !isDismissed && visible;
			    }
		
		    void drawJitteredShadow(Canvas c) {
			        final float baseAlpha = 0.20f * outerCircleAlpha;
			        outerCircleShadowPaint.setStyle(Paint.Style.FILL_AND_STROKE);
			        outerCircleShadowPaint.setAlpha((int) baseAlpha);
			        c.drawCircle(outerCircleCenter[0], outerCircleCenter[1] + SHADOW_DIM, outerCircleRadius, outerCircleShadowPaint);
			        outerCircleShadowPaint.setStyle(Paint.Style.STROKE);
			        final int numJitters = 7;
			        for (int i = numJitters - 1; i > 0; --i) {
				            outerCircleShadowPaint.setAlpha((int) ((i / (float) numJitters) * baseAlpha));
				            c.drawCircle(outerCircleCenter[0], outerCircleCenter[1] + SHADOW_DIM ,
				                    outerCircleRadius + (numJitters - i) * SHADOW_JITTER_DIM , outerCircleShadowPaint);
				        }
			    }
		
		    void drawDebugInformation(Canvas c) {
			        if (debugPaint == null) {
				            debugPaint = new Paint();
				            debugPaint.setARGB(255, 255, 0, 0);
				            debugPaint.setStyle(Paint.Style.STROKE);
				            debugPaint.setStrokeWidth(UiUtil.dp(getContext(), 1));
				        }
			
			        if (debugTextPaint == null) {
				            debugTextPaint = new TextPaint();
				            debugTextPaint.setColor(0xFFFF0000);
				            debugTextPaint.setTextSize(UiUtil.sp(getContext(), 16));
				        }
			
			        // Draw wireframe
			        debugPaint.setStyle(Paint.Style.STROKE);
			        c.drawRect(textBounds, debugPaint);
			        c.drawRect(targetBounds, debugPaint);
			        c.drawCircle(outerCircleCenter[0], outerCircleCenter[1], 10, debugPaint);
			        c.drawCircle(outerCircleCenter[0], outerCircleCenter[1], calculatedOuterCircleRadius - CIRCLE_PADDING, debugPaint);
			        c.drawCircle(targetBounds.centerX(), targetBounds.centerY(), TARGET_RADIUS + TARGET_PADDING, debugPaint);
			
			        // Draw positions and dimensions
			        debugPaint.setStyle(Paint.Style.FILL);
			        final String debugText =
			                "Text bounds: " + textBounds.toShortString() + "n" +
			                        "Target bounds: " + targetBounds.toShortString() + "n" +
			                        "Center: " + outerCircleCenter[0] + " " + outerCircleCenter[1] + "n" +
			                        "View size: " + getWidth() + " " + getHeight() + "n" +
			                        "Target bounds: " + targetBounds.toShortString();
			
			        if (debugStringBuilder == null) {
				            debugStringBuilder = new SpannableStringBuilder(debugText);
				        } else {
				            debugStringBuilder.clear();
				            debugStringBuilder.append(debugText);
				        }
			
			        if (debugLayout == null) {
				            debugLayout = new DynamicLayout(debugText, debugTextPaint, getWidth(), Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
				        }
			
			        final int saveCount = c.save();
			        {
				            debugPaint.setARGB(220, 0, 0, 0);
				            c.translate(0.0f, topBoundary);
				            c.drawRect(0.0f, 0.0f, debugLayout.getWidth(), debugLayout.getHeight(), debugPaint);
				            debugPaint.setARGB(255, 255, 0, 0);
				            debugLayout.draw(c);
				        }
			        c.restoreToCount(saveCount);
			    }
		
		    void drawTintedTarget() {
			        final android.graphics.drawable.Drawable icon = target.icon;
			        if (!shouldTintTarget || icon == null) {
				            tintedTarget = null;
				            return;
				        }
			
			        if (tintedTarget != null) return;
			
			        tintedTarget = Bitmap.createBitmap(icon.getIntrinsicWidth(), icon.getIntrinsicHeight(),
			                Bitmap.Config.ARGB_8888);
			        final Canvas canvas = new Canvas(tintedTarget);
			        icon.setColorFilter(new PorterDuffColorFilter(
			                outerCirclePaint.getColor(), PorterDuff.Mode.SRC_ATOP));
			        icon.draw(canvas);
			        icon.setColorFilter(null);
			    }
		
		    void updateTextLayouts() {
			        final int textWidth = Math.min(getWidth(), TEXT_MAX_WIDTH) - TEXT_PADDING * 2;
			        if (textWidth <= 0) {
				            return;
				        }
			
			        titleLayout = new StaticLayout(title, titlePaint, textWidth,
			                Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
			
			        if (description != null) {
				            descriptionLayout = new StaticLayout(description, descriptionPaint, textWidth,
				                    Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
				        } else {
				            descriptionLayout = null;
				        }
			    }
		
		    float halfwayLerp(float lerp) {
			        if (lerp < 0.5f) {
				            return lerp / 0.5f;
				        }
			
			        return (1.0f - lerp) / 0.5f;
			    }
		
		    float delayedLerp(float lerp, float threshold) {
			        if (lerp < threshold) {
				            return 0.0f;
				        }
			
			        return (lerp - threshold) / (1.0f - threshold);
			    }
		
		    void calculateDimensions() {
			        textBounds = getTextBounds();
			        outerCircleCenter = getOuterCircleCenterPoint();
			        calculatedOuterCircleRadius = getOuterCircleRadius(outerCircleCenter[0], outerCircleCenter[1], textBounds, targetBounds);
			    }
		
		    void calculateDrawingBounds() {
			        if (outerCircleCenter == null) {
				            // Called dismiss before we got a chance to display the tap target
				            // So we have no center -> cant determine the drawing bounds
				            return;
				        }
			        drawingBounds.left = (int) Math.max(0, outerCircleCenter[0] - outerCircleRadius);
			        drawingBounds.top = (int) Math.min(0, outerCircleCenter[1] - outerCircleRadius);
			        drawingBounds.right = (int) Math.min(getWidth(),
			                outerCircleCenter[0] + outerCircleRadius + CIRCLE_PADDING);
			        drawingBounds.bottom = (int) Math.min(getHeight(),
			                outerCircleCenter[1] + outerCircleRadius + CIRCLE_PADDING);
			    }
		
		    int getOuterCircleRadius(int centerX, int centerY, Rect textBounds, Rect targetBounds) {
			        final int targetCenterX = targetBounds.centerX();
			        final int targetCenterY = targetBounds.centerY();
			        final int expandedRadius = (int) (1.1f * TARGET_RADIUS);
			        final Rect expandedBounds = new Rect(targetCenterX, targetCenterY, targetCenterX, targetCenterY);
			        expandedBounds.inset(-expandedRadius, -expandedRadius);
			
			        final int textRadius = maxDistanceToPoints(centerX, centerY, textBounds);
			        final int targetRadius = maxDistanceToPoints(centerX, centerY, expandedBounds);
			        return Math.max(textRadius, targetRadius) + CIRCLE_PADDING;
			    }
		
		    Rect getTextBounds() {
			        final int totalTextHeight = getTotalTextHeight();
			        final int totalTextWidth = getTotalTextWidth();
			
			        final int possibleTop = targetBounds.centerY() - TARGET_RADIUS - TARGET_PADDING - totalTextHeight;
			        final int top;
			        if (possibleTop > topBoundary) {
				            top = possibleTop;
				        } else {
				            top = targetBounds.centerY() + TARGET_RADIUS + TARGET_PADDING;
				        }
			
			        final int relativeCenterDistance = (getWidth() / 2) - targetBounds.centerX();
			        final int bias = relativeCenterDistance < 0 ? -TEXT_POSITIONING_BIAS : TEXT_POSITIONING_BIAS;
			        final int left = Math.max(TEXT_PADDING, targetBounds.centerX() - bias - totalTextWidth);
			        final int right = Math.min(getWidth() - TEXT_PADDING, left + totalTextWidth);
			        return new Rect(left, top, right, top + totalTextHeight);
			    }
		
		    int[] getOuterCircleCenterPoint() {
			        if (inGutter(targetBounds.centerY())) {
				            return new int[]{targetBounds.centerX(), targetBounds.centerY()};
				        }
			
			        final int targetRadius = Math.max(targetBounds.width(), targetBounds.height()) / 2 + TARGET_PADDING;
			        final int totalTextHeight = getTotalTextHeight();
			
			        final boolean onTop = targetBounds.centerY() - TARGET_RADIUS - TARGET_PADDING - totalTextHeight > 0;
			
			        final int left = Math.min(textBounds.left, targetBounds.left - targetRadius);
			        final int right = Math.max(textBounds.right, targetBounds.right + targetRadius);
			        final int titleHeight = titleLayout == null ? 0 : titleLayout.getHeight();
			        final int centerY = onTop ?
			                targetBounds.centerY() - TARGET_RADIUS - TARGET_PADDING - totalTextHeight + titleHeight
			                :
			                targetBounds.centerY() + TARGET_RADIUS + TARGET_PADDING + titleHeight;
			
			        return new int[] { (left + right) / 2, centerY };
			    }
		
		    int getTotalTextHeight() {
			        if (titleLayout == null) {
				            return 0;
				        }
			
			        if (descriptionLayout == null) {
				            return titleLayout.getHeight() + TEXT_SPACING;
				        }
			
			        return titleLayout.getHeight() + descriptionLayout.getHeight() + TEXT_SPACING;
			    }
		
		    int getTotalTextWidth() {
			        if (titleLayout == null) {
				            return 0;
				        }
			
			        if (descriptionLayout == null) {
				            return titleLayout.getWidth();
				        }
			
			        return Math.max(titleLayout.getWidth(), descriptionLayout.getWidth());
			    }
		    boolean inGutter(int y) {
			        if (bottomBoundary > 0) {
				            return y < GUTTER_DIM || y > bottomBoundary - GUTTER_DIM;
				        } else {
				            return y < GUTTER_DIM || y > getHeight() - GUTTER_DIM;
				        }
			    }
		    int maxDistanceToPoints(int x1, int y1, Rect bounds) {
			        final double tl = distance(x1, y1, bounds.left, bounds.top);
			        final double tr = distance(x1, y1, bounds.right, bounds.top);
			        final double bl = distance(x1, y1, bounds.left, bounds.bottom);
			        final double br = distance(x1, y1, bounds.right, bounds.bottom);
			        return (int) Math.max(tl, Math.max(tr, Math.max(bl, br)));
			    }
		    double distance(int x1, int y1, int x2, int y2) {
			        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
			    }
		    void invalidateViewAndOutline(Rect bounds) {
			        invalidate(bounds);
			        if (outlineProvider != null && Build.VERSION.SDK_INT >= 21) {
				            invalidateOutline();
				        }
			    }
	}
			static class ViewUtil {
		
		    ViewUtil() {}
		
		    private static boolean isLaidOut(View view) {
			        return true;
			    }
		    static void onLaidOut(final View view, final Runnable runnable) {
			        if (isLaidOut(view)) {
				            runnable.run();
				            return;
				        }
			        final ViewTreeObserver observer = view.getViewTreeObserver();
			        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				            @Override
				            public void onGlobalLayout() {
					                final ViewTreeObserver trueObserver;
					                if (observer.isAlive()) {
						                    trueObserver = observer;
						                } else {
						                    trueObserver = view.getViewTreeObserver();
						                }
					                removeOnGlobalLayoutListener(trueObserver, this);
					                runnable.run();
					            }
				        });
			    }
		    @SuppressWarnings("deprecation")
		    static void removeOnGlobalLayoutListener(ViewTreeObserver observer,
		                                             ViewTreeObserver.OnGlobalLayoutListener listener) {
			        if (Build.VERSION.SDK_INT >= 16) {
				            observer.removeOnGlobalLayoutListener(listener);
				        } else {
				            observer.removeGlobalOnLayoutListener(listener);
				        }
			    }
		    static void removeView(ViewManager parent, View child) {
			        if (parent == null || child == null) {
				            return;
				        }
			        try {
				            parent.removeView(child);
				        } catch (Exception ignored) {
				        }
			    }
	}
			static class ViewTapTarget extends TapTarget {
		    final View view;
		
		    ViewTapTarget(View view, CharSequence title,  CharSequence description) {
			        super(title, description);
			        if (view == null) {
				            throw new IllegalArgumentException("Given null view to target");
				        }
			        this.view = view;
			    }
		
		    @Override
		    public void onReady(final Runnable runnable) {
			        ViewUtil.onLaidOut(view, new Runnable() {
				            @Override
				            public void run() {
					                // Cache bounds
					                final int[] location = new int[2];
					                view.getLocationOnScreen(location);
					                bounds = new Rect(location[0], location[1],
					                        location[0] + view.getWidth(), location[1] + view.getHeight());
					
					                if (icon == null && view.getWidth() > 0 && view.getHeight() > 0) {
						                    final Bitmap viewBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
						                    final Canvas canvas = new Canvas(viewBitmap);
						                    view.draw(canvas);
						                    icon = new android.graphics.drawable.BitmapDrawable(view.getContext().getResources(), viewBitmap);
						                    icon.setBounds(0, 0, icon.getIntrinsicWidth(), icon.getIntrinsicHeight());
						                }
					
					                runnable.run();
					            }
				        });
			    }
	}
			static class TapTargetSequence {
		    private final Activity activity;
		    private final Dialog dialog;
		    private final Queue<TapTarget> targets;
		    private boolean active;
		    private TapTargetView currentView;
		    Listener listener;
		    boolean considerOuterCircleCanceled;
		    boolean continueOnCancel;
		    public interface Listener {
			        void onSequenceFinish();
			        void onSequenceStep(TapTarget lastTarget, boolean targetClicked);
			        void onSequenceCanceled(TapTarget lastTarget);
			    }
		    public TapTargetSequence(Activity activity) {
			        if (activity == null) throw new IllegalArgumentException("Activity is null");
			        this.activity = activity;
			        this.dialog = null;
			        this.targets = new LinkedList<>();
			    }
		    public TapTargetSequence(Dialog dialog) {
			        if (dialog == null) throw new IllegalArgumentException("Given null Dialog");
			        this.dialog = dialog;
			        this.activity = null;
			        this.targets = new LinkedList<>();
			    }
		    public TapTargetSequence targets(List<TapTarget> targets) {
			        this.targets.addAll(targets);
			        return this;
			    }
		    public TapTargetSequence targets(TapTarget... targets) {
			        Collections.addAll(this.targets, targets);
			        return this;
			    }
		    public TapTargetSequence target(TapTarget target) {
			        this.targets.add(target);
			        return this;
			    }
		    public TapTargetSequence continueOnCancel(boolean status) {
			        this.continueOnCancel = status;
			        return this;
			    }
		    public TapTargetSequence considerOuterCircleCanceled(boolean status) {
			        this.considerOuterCircleCanceled = status;
			        return this;
			    }
		    public TapTargetSequence listener(Listener listener) {
			        this.listener = listener;
			        return this;
			    }
		    public void start() {
			        if (targets.isEmpty() || active) {
				            return;
				        }
			        active = true;
			        showNext();
			    }
		    public void startWith(int targetId) {
			        if (active) {
				            return;
				        }
			        while (targets.peek() != null && targets.peek().id() != targetId) {
				            targets.poll();
				        }
			        TapTarget peekedTarget = targets.peek();
			        if (peekedTarget == null || peekedTarget.id() != targetId) {
				            throw new IllegalStateException("Given target " + targetId + " not in sequence");
				        }
			        start();
			    }
		    public void startAt(int index) {
			        if (active) {
				            return;
				        }
			        if (index < 0 || index >= targets.size()) {
				            throw new IllegalArgumentException("Given invalid index " + index);
				        }
			        final int expectedSize = targets.size() - index;
			        while (targets.peek() != null && targets.size() != expectedSize) {
				            targets.poll();
				        }
			        if (targets.size() != expectedSize) {
				            throw new IllegalStateException("Given index " + index + " not in sequence");
				        }
			        start();
			    }
		    public boolean cancel() {
			        if (targets.isEmpty() || !active) {
				            return false;
				        }
			        if (currentView == null || !currentView.cancelable) {
				            return false;
				        }
			        currentView.dismiss(false);
			        active = false;
			        targets.clear();
			        if (listener != null) {
				            listener.onSequenceCanceled(currentView.target);
				        }
			        return true;
			    }
		    void showNext() {
			        try {
				            TapTarget tapTarget = targets.remove();
				            if (activity != null) {
					                currentView = TapTargetView.showFor(activity, tapTarget, tapTargetListener);
					            } else {
					                currentView = TapTargetView.showFor(dialog, tapTarget, tapTargetListener);
					            }
				        } catch (NoSuchElementException e) {
				            // No more targets
				            if (listener != null) {
					                listener.onSequenceFinish();
					            }
				        }
			    }
		    private final TapTargetView.Listener tapTargetListener = new TapTargetView.Listener() {
			        @Override
			        public void onTargetClick(TapTargetView view) {
				            super.onTargetClick(view);
				            if (listener != null) {
					                listener.onSequenceStep(view.target, true);
					            }
				            showNext();
				        }
			        @Override
			        public void onOuterCircleClick(TapTargetView view) {
				            if (considerOuterCircleCanceled) {
					                onTargetCancel(view);
					            }
				        }
			        @Override
			        public void onTargetCancel(TapTargetView view) {
				            super.onTargetCancel(view);
				            if (continueOnCancel) {
					                if (listener != null) {
						                    listener.onSequenceStep(view.target, false);
						                }
					                showNext();
					            } else {
					                if (listener != null) {
						                    listener.onSequenceCanceled(view.target);
						                }
					            }
				        }
			    };
	}
	public void _MoreBlocks() {
	}
	public static abstract class BaseTransformer implements androidx.viewpager.widget.ViewPager.PageTransformer {
			protected abstract void onTransform(View view, float position);
			@Override
			public void transformPage(View view, float position) {
					onPreTransform(view, position);
					onTransform(view, position);
					onPostTransform(view, position);
			}
			protected boolean hideOffscreenPages() {
					return true;
			}
			protected boolean isPagingEnabled() {
					return false;
			}
			protected void onPreTransform(View view, float position) {
					final float width = view.getWidth();
					view.setRotationX(0);
					view.setRotationY(0);
					view.setRotation(0);
					view.setScaleX(1);
					view.setScaleY(1);
					view.setPivotX(0);
					view.setPivotY(0);
					view.setTranslationY(0);
					view.setTranslationX(isPagingEnabled() ? 0f : -width * position);
					if (hideOffscreenPages()) {
							view.setAlpha(position <= -1f || position >= 1f ? 0f : 1f);
					} else {
							view.setAlpha(1f);
					}
			}
			protected void onPostTransform(View view, float position) {
			}
	}
	public static class AccordionTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					view.setPivotX(position < 0 ? 0 : view.getWidth());
					view.setScaleX(position < 0 ? 1f + position : 1f - position);
			}
	}
	public static class BackgroundToForegroundTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float height = view.getHeight();
					final float width = view.getWidth();
					final float scale = min(position < 0 ? 1f : Math.abs(1f - position), 0.5f);
					view.setScaleX(scale);
					view.setScaleY(scale);
					view.setPivotX(width * 0.5f);
					view.setPivotY(height * 0.5f);
					view.setTranslationX(position < 0 ? width * position : -width * position * 0.25f);
			}
			private static final float min(float val, float min) {
					return val < min ? min : val;
			}
	}
	public static class CubeInTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					view.setPivotX(position > 0 ? 0 : view.getWidth());
					view.setPivotY(0);
					view.setRotationY(-90f * position);
			}
			@Override
			public boolean isPagingEnabled() {
					return true;
			}
	}
	public static class CubeOutTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					view.setPivotX(position < 0f ? view.getWidth() : 0f);
					view.setPivotY(view.getHeight() * 0.5f);
					view.setRotationY(90f * position);
			}
			@Override
			public boolean isPagingEnabled() {
					return true;
			}
	}
	public static class DefaultTransformer extends BaseTransformer {
			@Override protected void onTransform(View view, float position) {}
			@Override public boolean isPagingEnabled() {
					return true;
			}
	}
	public static class DepthPageTransformer extends BaseTransformer {
			private static final float MIN_SCALE = 0.75f;
			@Override
			protected void onTransform(View view, float position) {
					if (position <= 0f) {
							view.setTranslationX(0f);
							view.setScaleX(1f);
							view.setScaleY(1f);
					} else if (position <= 1f) {
							final float scaleFactor = MIN_SCALE + (1 - MIN_SCALE) * (1 - Math.abs(position));
							view.setAlpha(1 - position);
							view.setPivotY(0.5f * view.getHeight());
							view.setTranslationX(view.getWidth() * -position);
							view.setScaleX(scaleFactor);
							view.setScaleY(scaleFactor);
					}
			}
			@Override
			protected boolean isPagingEnabled() {
					return true;
			}
	}
	public static class ZoomOutTranformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float scale = 1f + Math.abs(position);
					view.setScaleX(scale);
					view.setScaleY(scale);
					view.setPivotX(view.getWidth() * 0.5f);
					view.setPivotY(view.getHeight() * 0.5f);
					view.setAlpha(position < -1f || position > 1f ? 0f : 1f - (scale - 1f));
					if(position == -1){
							view.setTranslationX(view.getWidth() * -1);
					}
			}
	}
	public static class StackTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					view.setTranslationX(position < 0 ? 0f : -view.getWidth() * position);
			}
	}
	public static class TabletTransformer extends BaseTransformer {
			private static final Matrix OFFSET_MATRIX = new Matrix();
			private static final Camera OFFSET_CAMERA = new Camera();
			private static final float[] OFFSET_TEMP_FLOAT = new float[2];
			@Override
			protected void onTransform(View view, float position) {
					final float rotation = (position < 0 ? 30f : -30f) * Math.abs(position);
					view.setTranslationX(getOffsetXForRotation(rotation, view.getWidth(), view.getHeight()));
					view.setPivotX(view.getWidth() * 0.5f);
					view.setPivotY(0);
					view.setRotationY(rotation);
			}
			protected static final float getOffsetXForRotation(float degrees, int width, int height) {
					OFFSET_MATRIX.reset();
					OFFSET_CAMERA.save();
					OFFSET_CAMERA.rotateY(Math.abs(degrees));
					OFFSET_CAMERA.getMatrix(OFFSET_MATRIX);
					OFFSET_CAMERA.restore();
					OFFSET_MATRIX.preTranslate(-width * 0.5f, -height * 0.5f);
					OFFSET_MATRIX.postTranslate(width * 0.5f, height * 0.5f);
					OFFSET_TEMP_FLOAT[0] = width;
					OFFSET_TEMP_FLOAT[1] = height;
					OFFSET_MATRIX.mapPoints(OFFSET_TEMP_FLOAT);
					return (width - OFFSET_TEMP_FLOAT[0]) * (degrees > 0.0f ? 1.0f : -1.0f);
			}
	}
	public static class ZoomInTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float scale = position < 0 ? position + 1f : Math.abs(1f - position);
					view.setScaleX(scale);
					view.setScaleY(scale);
					view.setPivotX(view.getWidth() * 0.5f);
					view.setPivotY(view.getHeight() * 0.5f);
					view.setAlpha(position < -1f || position > 1f ? 0f : 1f - (scale - 1f));
			}
	}
	public static class ZoomOutSlideTransformer extends BaseTransformer {
			private static final float MIN_SCALE = 0.85f;
			private static final float MIN_ALPHA = 0.5f;
			@Override
			protected void onTransform(View view, float position) {
					if (position >= -1 || position <= 1) {
							final float height = view.getHeight();
							final float scaleFactor = Math.max(MIN_SCALE, 1 - Math.abs(position));
							final float vertMargin = height * (1 - scaleFactor) / 2;
							final float horzMargin = view.getWidth() * (1 - scaleFactor) / 2;
							view.setPivotY(0.5f * height);
							if (position < 0) {
									view.setTranslationX(horzMargin - vertMargin / 2);
							} else {
									view.setTranslationX(-horzMargin + vertMargin / 2);
							}
							view.setScaleX(scaleFactor);
							view.setScaleY(scaleFactor);
							view.setAlpha(MIN_ALPHA + (scaleFactor - MIN_SCALE) / (1 - MIN_SCALE) * (1 - MIN_ALPHA));
					}
			}
	}
	public static class ForegroundToBackgroundTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float height = view.getHeight();
					final float width = view.getWidth();
					final float scale = min(position > 0 ? 1f : Math.abs(1f + position), 0.5f);
					view.setScaleX(scale);
					view.setScaleY(scale);
					view.setPivotX(width * 0.5f);
					view.setPivotY(height * 0.5f);
					view.setTranslationX(position > 0 ? width * position : -width * position * 0.25f);
			}
			private static final float min(float val, float min) {
					return val < min ? min : val;
			}
	}
	public static class ParallaxPageTransformer extends BaseTransformer {
		    private final int viewToParallax;
		    public ParallaxPageTransformer(final int viewToParallax) {
			        this.viewToParallax = viewToParallax;
			    }
		    @Override
		    protected void onTransform(View view, float position) {
			        int pageWidth = view.getWidth();
			        if (position < -1) {
				            view.setAlpha(1);
				        } else if (position <= 1) {
				            view.findViewById(viewToParallax).setTranslationX(-position * (pageWidth / 2));
				        } else {
				            view.setAlpha(1);
				        }
			    }
	}
	public static class RotateDownTransformer extends BaseTransformer {
			private static final float ROT_MOD = -15f;
			@Override
			protected void onTransform(View view, float position) {
					final float width = view.getWidth();
					final float height = view.getHeight();
					final float rotation = ROT_MOD * position * -1.25f;
					view.setPivotX(width * 0.5f);
					view.setPivotY(height);
					view.setRotation(rotation);
			}
			@Override
			protected boolean isPagingEnabled() {
					return true;
			}
	}
	public static class RotateUpTransformer extends BaseTransformer {
			private static final float ROT_MOD = -15f;
			@Override
			protected void onTransform(View view, float position) {
					final float width = view.getWidth();
					final float rotation = ROT_MOD * position;
					view.setPivotX(width * 0.5f);
					view.setPivotY(0f);
					view.setTranslationX(0f);
					view.setRotation(rotation);
			}
			@Override
			protected boolean isPagingEnabled() {
					return true;
			}
	}
	public static class DrawFromBackTransformer implements androidx.viewpager.widget.ViewPager.PageTransformer {
			private static final float MIN_SCALE = 0.75f;
			@Override
			public void transformPage(View view, float position) {
					int pageWidth = view.getWidth();
					if (position < -1 || position > 1) {
							view.setAlpha(0);
							return;
					}
					if (position <= 0) {
							view.setAlpha(1 + position);
							view.setTranslationX(pageWidth * -position);
							float scaleFactor = MIN_SCALE
									+ (1 - MIN_SCALE) * (1 - Math.abs(position));
							view.setScaleX(scaleFactor);
							view.setScaleY(scaleFactor);
							return;
					}
					if (position > 0.5 && position <= 1) {
							view.setAlpha(0);
							view.setTranslationX(pageWidth * -position);
							return;
					}
					if (position > 0.3 && position <= 0.5) {
							view.setAlpha(1);
							view.setTranslationX(pageWidth * position);
							float scaleFactor = MIN_SCALE;
							view.setScaleX(scaleFactor);
							view.setScaleY(scaleFactor);
							return;
					}
					if (position <= 0.3) {
							view.setAlpha(1);
							view.setTranslationX(pageWidth * position);
							float v = (float) (0.3 - position);
							v = v >= 0.25f ? 0.25f : v;
							float scaleFactor = MIN_SCALE + v;
							view.setScaleX(scaleFactor);
							view.setScaleY(scaleFactor);
					}
			}
	}
	public static class FlipHorizontalTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float rotation = 180f * position;
					view.setVisibility(rotation > 90f || rotation < -90f ? View.INVISIBLE : View.VISIBLE);
					view.setPivotX(view.getWidth() * 0.5f);
					view.setPivotY(view.getHeight() * 0.5f);
					view.setRotationY(rotation);
			}
	}
	public static class FlipVerticalTransformer extends BaseTransformer {
			@Override
			protected void onTransform(View view, float position) {
					final float rotation = -180f * position;
					view.setVisibility(rotation > 90f || rotation < -90f ? View.INVISIBLE : View.VISIBLE);
					view.setPivotX(view.getWidth() * 0.5f);
					view.setPivotY(view.getHeight() * 0.5f);
					view.setRotationX(rotation);
			}
	}
	{
	}
	int BOTTOM = 3;
	int TOP = 1;
	int CENTER = 2;
	
	public void AlphaToast(Context context, String str, int i, int i2, int i3, int i4, int i5){
		Toast makeText = Toast.makeText(context,str, 0);
		        View view = makeText.getView();
		        TextView textView = (TextView) view.findViewById(16908299);
		        textView.setTextSize(i);
		        textView.setTextColor(i2);
		        textView.setGravity(i5);
		        GradientDrawable gradientDrawable = new GradientDrawable();
		        gradientDrawable.setColor(i3);
		        gradientDrawable.setCornerRadius(i4);
		        view.setBackgroundDrawable(gradientDrawable);
		        view.setPadding(15, 10, 15, 10);
		        view.setElevation(10.0f);
		
		        switch (i5) {
			            case 1:
			                makeText.setGravity(48, 0, 150);
			                break;
			            case 2:
			                makeText.setGravity(17, 0, 0);
			                break;
			            case 3:
			                makeText.setGravity(80, 0, 150);
			                break;
			        }
		        makeText.show();
	}
	{
	}
	
	
	public void _RecycleView1() {
		for(int _repeat10 = 0; _repeat10 < (int)(2); _repeat10++) {
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212231_1439.jpg");
			map_recyclerview1.put("role", "Assassin");
			map_recyclerview1.put("count", "12 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212231_1973.jpg");
			map_recyclerview1.put("role", "Tank");
			map_recyclerview1.put("count", "18 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2227.jpg");
			map_recyclerview1.put("role", "Fighter");
			map_recyclerview1.put("count", "33 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2497.jpg");
			map_recyclerview1.put("role", "Mage");
			map_recyclerview1.put("count", "26 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212232_2867.jpg");
			map_recyclerview1.put("role", "Marksman");
			map_recyclerview1.put("count", "19 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
			map_recyclerview1 = new HashMap<>();
			map_recyclerview1.put("img1", "https://github.com/akosighost/Home-image/raw/main/Compress_20220305_212233_3147.jpg");
			map_recyclerview1.put("role", "Support");
			map_recyclerview1.put("count", "8 Heroes Available");
			listmap_recyclerview1.add(map_recyclerview1);
		}
		final CarouselLayoutManager recyclerview1layout = new CarouselLayoutManager(CarouselLayoutManager.HORIZONTAL,true); 
		recyclerview1layout.setPostLayoutListener(new CarouselZoomPostLayoutListener());
		recyclerview1.addOnScrollListener(new CenterScrollListener()); recyclerview1.setLayoutManager(recyclerview1layout); 
		recyclerview1.setHasFixedSize(true);
		recyclerview1.setAdapter(new Recyclerview1Adapter(listmap_recyclerview1));
		recyclerview1layout.addOnItemSelectionListener(new CarouselLayoutManager.OnCenterItemSelectionListener() { 
				@Override public void onCenterItemChanged(final int adapterPosition)
				 {
						 if (CarouselLayoutManager.INVALID_POSITION != adapterPosition) { 
								final int value = adapterPosition;
								textview9.setText(listmap_recyclerview1.get((int)/*recyclerview1*/value).get("role").toString());
					textview10.setText(listmap_recyclerview1.get((int)/*recyclerview1*/value).get("count").toString());
								 } } });
	}
	
	
	public void _PushDown() {
		PushDownAnim.setPushDownAnimTo(imageview1).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				startActivity(new Intent(HomeActivity.this, SettingsActivity.class)); Animatoo.animateFade(HomeActivity.this);
				 } } );
		PushDownAnim.setPushDownAnimTo(imageview2).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://youtube.com/channel/UCKMImvTtq7AYkBWLCW9xfmQ"));
				startActivity(intent);
				 } } );
		PushDownAnim.setPushDownAnimTo(linear12).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				CustomDialog = new AlertDialog.Builder(HomeActivity.this).create();
				LayoutInflater CustomDialogLI = getLayoutInflater();
				View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.choice, null);
				CustomDialog.setView(CustomDialogCV);
				CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
				final LinearLayout l1 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear1);
				final TextView t1 = (TextView)
				CustomDialogCV.findViewById(R.id.textview1);
				final TextView t2 = (TextView)
				CustomDialogCV.findViewById(R.id.textview2);
				android.graphics.drawable.GradientDrawable linear1gd = new android.graphics.drawable.GradientDrawable();
				
				linear1gd.setColor(0xFF0B141D);
				
				linear1gd.setStroke((int)0, Color.TRANSPARENT);
				
				linear1gd.setCornerRadii(new float[]{(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8});
				
				linear1.setBackground(linear1gd);
				
				linear1.setElevation(50);
				t1.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						CustomDialog.dismiss();
						startActivity(new Intent(HomeActivity.this, RecentActivity.class)); Animatoo.animateFade(HomeActivity.this);
					}
				});
				t2.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						CustomDialog.dismiss();
						final com.google.android.material.bottomsheet.BottomSheetDialog BottomSheetD = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
						View BottomSheetV;
						BottomSheetV = getLayoutInflater().inflate(R.layout.bottomsheet,null );
						BottomSheetD.setContentView(BottomSheetV);
						BottomSheetD.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
						final LinearLayout l1 = (LinearLayout) BottomSheetV.findViewById(R.id.linear1);
						final LinearLayout l4 = (LinearLayout) BottomSheetV.findViewById(R.id.linear4);
						final ScrollView scroll = (ScrollView) BottomSheetV.findViewById(R.id.vscroll1);
						final TextView t4 = (TextView) BottomSheetV.findViewById(R.id.textview4);
						t4.setTextSize((float)13);
						t4.setText("• Optimized Ui/UX\n• Fix some bugs\n\n• Added 1 New Heroes\n  Julian (Mage)\n\n• Added New Upcoming Skins\n  Ling - MWorld\n  Wanwan - MWorld\n  Yin - MWorld\n\n  Brody - Collector\n  Guinevere - Legend\n  Benedetta - Special\n  Aulus - Elite\n  Zilong - 515\n\n• Fix Skin\n  Fanny Aspirant (Fix Audio)\n  Ling - MWorld (Fix Audio & Effects)\n\n• Fix Effect\n  Seal of Anvil (Fix Audio)");
						android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
						
						l1gd.setColor(0xFF121F2B);
						
						l1gd.setStroke((int)0, Color.TRANSPARENT);
						
						l1gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
						
						l1.setBackground(l1gd);
						
						l1.setElevation(5);
						android.graphics.drawable.GradientDrawable l4gd = new android.graphics.drawable.GradientDrawable();
						
						l4gd.setColor(0xFF121F2B);
						
						l4gd.setStroke((int)0, Color.TRANSPARENT);
						
						l4gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
						
						l4.setBackground(l4gd);
						
						l4.setElevation(5);
						scroll.setHorizontalScrollBarEnabled(false);
						scroll.setVerticalScrollBarEnabled(false);
						scroll.setOverScrollMode(ScrollView.OVER_SCROLL_NEVER);
						BottomSheetD.show();
					}
				});
				CustomDialog.setCancelable(true);
				CustomDialog.show();
				 } } );
		PushDownAnim.setPushDownAnimTo(linear14).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				_Progress(true);
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_Progress(false);
								AlphaToast(HomeActivity.this,"You are using the latest version",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2000));
				 } } );
		linear27.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				AlphaToast(HomeActivity.this,"Coming soon",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
			}
		});
	}
	
	
	public void _ObjectAnimator(final View _view, final String _setProperty, final double _setValue, final double _setValueFrom, final double _to, final double _duration) {
		ObjectAnimator anim = new ObjectAnimator();
		anim.setTarget(_view);
		anim.setPropertyName(_setProperty);
		anim.setFloatValues((float)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - _setValue));
		anim.setFloatValues((float)(_setValueFrom), (float)(_to));
		anim.setDuration((int)(_duration));
		anim.start();
	}
	
	
	public void _CategoryAnimation() {
		if (role) {
			_ObjectAnimator(linear21, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - -40, -40, 1, 1300);
			_ObjectAnimator(linear19, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 40, 40, 1, 1300);
			_ObjectAnimator(linear21, "alpha", 0, 0, 1, 700);
			_ObjectAnimator(linear19, "alpha", 0, 0, 1, 700);
			role = false;
		}
		else {
			_ObjectAnimator(linear21, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 1, 1, -40, 1000);
			_ObjectAnimator(linear19, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 1, 1, 40, 1000);
			_ObjectAnimator(linear21, "alpha", 1, 1, 0, 1000);
			_ObjectAnimator(linear19, "alpha", 1, 1, 0, 1000);
			role = true;
		}
	}
	
	
	public void _EffectAnimation() {
		if (effect) {
			_ObjectAnimator(linear23, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - -40, -40, 1, 1300);
			_ObjectAnimator(linear25, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 40, 40, 1, 1300);
			_ObjectAnimator(linear23, "alpha", 0, 0, 1, 700);
			_ObjectAnimator(linear25, "alpha", 0, 0, 1, 700);
			effect = false;
		}
		else {
			_ObjectAnimator(linear23, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 1, 1, -40, 1000);
			_ObjectAnimator(linear25, "translationY", SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) - 1, 1, 40, 1000);
			_ObjectAnimator(linear23, "alpha", 1, 1, 0, 1000);
			_ObjectAnimator(linear25, "alpha", 1, 1, 0, 1000);
			effect = true;
		}
	}
	
	
	public void _Progress(final boolean _ifShow) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.requestWindowFeature(Window.FEATURE_NO_TITLE);  prog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			prog.setMessage(null);
			prog.show();
			prog.setContentView(R.layout.loading);
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.category, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			
			Glide.with(getApplicationContext())
			.load(_data.get((int)_position).get("img1").toString())
			.placeholder(R.drawable.transparent)
			.transform(new com.bumptech.glide.load.resource.bitmap.RoundedCorners((int)10))
			.into(imageview1);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						_CategoryAnimation();
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										intent.setClass(getApplicationContext(), ListCategoryActivity.class);
										intent.putExtra("category", _data.get((int)_position).get("role").toString());
										intent.putExtra("list", _data.get((int)_position).get("count").toString());
										startActivity(intent);
										overridePendingTransition(R.anim.fin, R.anim.fout);
									}
								});
							}
						};
						_timer.schedule(timer, (int)(400));
					}
					else {
						AlphaToast(HomeActivity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Viewpager1Adapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public Viewpager1Adapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public Viewpager1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.effect, _container, false);
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF0B141A);
				SketchUi.setCornerRadius(d*10);
				linear3.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear3.setBackground(SketchUiRD);
				linear3.setClickable(true);
			}
			android.graphics.drawable.GradientDrawable linear2gd = new android.graphics.drawable.GradientDrawable();
			
			linear2gd.setColor(0xFF121F2B);
			
			linear2gd.setStroke((int)0, Color.TRANSPARENT);
			
			linear2gd.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
			
			linear2.setBackground(linear2gd);
			
			linear2.setElevation(50);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img1").toString())).into(imageview1);
			if (_data.get((int)_position).get("txt2").toString().equals("0")) {
				linear1.setVisibility(View.GONE);
			}
			else {
				linear1.setVisibility(View.VISIBLE);
			}
			cardview1.setCardBackgroundColor(Color.TRANSPARENT);
			cardview1.setRadius((float)15);
			linear3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_EffectAnimation();
					timer = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (SketchwareUtil.isConnected(getApplicationContext())) {
										intent.setClass(getApplicationContext(), ListeffectAndroid11Activity.class);
										intent.putExtra("effect", _data.get((int)_position).get("txt1").toString());
										intent.putExtra("count", _data.get((int)_position).get("txt2").toString());
										startActivity(intent);
										overridePendingTransition(R.anim.fin, R.anim.fout);
									}
									else {
										AlphaToast(HomeActivity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
									}
								}
							});
						}
					};
					_timer.schedule(timer, (int)(400));
				}
			});
			
			_container.addView(_view);
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}