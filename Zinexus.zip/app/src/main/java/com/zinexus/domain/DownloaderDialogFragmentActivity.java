package com.zinexus.domain;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.kaopiz.kprogresshud.*;
import com.thekhaeng.pushdownanim.*;
import com.twotoasters.jazzylistview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import com.downloader.Error;
import com.downloader.OnCancelListener;
import com.downloader.OnDownloadListener;
import com.downloader.OnPauseListener;
import com.downloader.OnProgressListener;
import com.downloader.OnStartOrResumeListener;
import com.downloader.PRDownloader;
import com.downloader.Progress;
import com.downloader.Status;
import com.downloader.PRDownloader;
import com.downloader.PRDownloaderConfig;

public class DownloaderDialogFragmentActivity extends DialogFragment {
	
	private double number = 0;
	private  int downloadIdTwo;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private TextView textview1;
	private ProgressBar progressbar1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview2;
	private TextView textview3;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private SharedPreferences sp;
	private Toast CustomToast;
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.downloader_dialog_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear1 = _view.findViewById(R.id.linear1);
		linear2 = _view.findViewById(R.id.linear2);
		linear3 = _view.findViewById(R.id.linear3);
		textview1 = _view.findViewById(R.id.textview1);
		progressbar1 = _view.findViewById(R.id.progressbar1);
		linear4 = _view.findViewById(R.id.linear4);
		linear5 = _view.findViewById(R.id.linear5);
		linear6 = _view.findViewById(R.id.linear6);
		textview2 = _view.findViewById(R.id.textview2);
		textview3 = _view.findViewById(R.id.textview3);
		net = new RequestNetwork((Activity) getContext());
		sp = getContext().getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (number == 1) {
					number = 0;
					textview2.setText("P A U S E    ");
					PRDownloader.resume(downloadIdTwo);
				}
				else {
					if (number == 0) {
						number = 1;
						textview2.setText("R E S U M E");
						PRDownloader.pause(downloadIdTwo);
					}
				}
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				PRDownloader.cancel(downloadIdTwo);
				dismiss();
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
		getDialog().getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		setCancelable(false);
		android.graphics.drawable.GradientDrawable linear1gd = new android.graphics.drawable.GradientDrawable();
		
		linear1gd.setColor(0xFF0B141D);
		
		linear1gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear1gd.setCornerRadii(new float[]{(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8});
		
		linear1.setBackground(linear1gd);
		
		linear1.setElevation(50);
		PRDownloaderConfig config = PRDownloaderConfig.newBuilder()
		.setDatabaseEnabled(true)
		.build();
		PRDownloader.initialize(getContext().getApplicationContext(), config);
		
		downloadIdTwo = PRDownloader.download(sp.getString("link", ""), "storage/emulated/0/Android/data/com.mobile.legends/files/", "Script.zip")
		.build()
		 .setOnStartOrResumeListener(new OnStartOrResumeListener() {
			@Override
			public void onStartOrResume() {
				 
			}
		})
		.setOnPauseListener(new OnPauseListener() {
			@Override
			public void onPause() {
				 
			}
		})
		.setOnCancelListener(new OnCancelListener() {
			@Override
			public void onCancel() {
				 
			}
		})
		.setOnProgressListener(new OnProgressListener() {
			@Override
			public void onProgress(Progress progress) {
				long progressPercent = progress.currentBytes * 100 / progress.totalBytes;
				textview1.setText(Utils.getProgressDisplayLine(progress.currentBytes, progress.totalBytes));
				progressbar1.setProgress((int)progressPercent);
			}
		})
		 .start(new OnDownloadListener() {
			@Override
			public void onDownloadComplete() {
				_xtra("storage/emulated/0/Android/data/com.mobile.legends/files/Script.zip", "storage/emulated/0/Android/data/com.mobile.legends/files/dragon2017/");
				FileUtil.deleteFile("storage/emulated/0/Android/data/com.mobile.legends/files/Script.zip");
				dismiss();
				LayoutInflater CustomToastLT = getActivity().getLayoutInflater(); 
				View CustomToastVT = CustomToastLT.inflate(R.layout.success, null);
				Toast CustomToastT = Toast.makeText(getContext().getApplicationContext(),"",500);
				CustomToastT.setView(CustomToastVT);
				CustomToastT.show();
			}
			@Override
			public void onError(Error error) {
				SketchwareUtil.showMessage(getContext().getApplicationContext(), "error");
			}
		});
	}
	
	public void _xtra(final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _MoreBlocks() {
	}
	int BOTTOM = 3;
	int TOP = 1;
	int CENTER = 2;
	
	public void AlphaToast(Context context, String str, int i, int i2, int i3, int i4, int i5){
		Toast makeText = Toast.makeText(context,str, 0);
		        View view = makeText.getView();
		        TextView textView = (TextView) view.findViewById(16908299);
		        textView.setTextSize(i);
		        textView.setTextColor(i2);
		        textView.setGravity(i5);
		        GradientDrawable gradientDrawable = new GradientDrawable();
		        gradientDrawable.setColor(i3);
		        gradientDrawable.setCornerRadius(i4);
		        view.setBackgroundDrawable(gradientDrawable);
		        view.setPadding(15, 10, 15, 10);
		        view.setElevation(10.0f);
		
		        switch (i5) {
			            case 1:
			                makeText.setGravity(48, 0, 150);
			                break;
			            case 2:
			                makeText.setGravity(17, 0, 0);
			                break;
			            case 3:
			                makeText.setGravity(80, 0, 150);
			                break;
			        }
		        makeText.show();
	}
	{
	}
	
}