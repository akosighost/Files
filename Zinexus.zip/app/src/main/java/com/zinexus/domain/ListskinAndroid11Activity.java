package com.zinexus.domain;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.azoft.carousellayoutmanager.*;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.downloader.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.kaopiz.kprogresshud.*;
import com.thekhaeng.pushdownanim.*;
import com.twotoasters.jazzylistview.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import jp.wasabeef.picasso.transformations.*;
import me.everything.*;
import org.json.*;
import java.io.*;
import java.util.zip.*;
import androidx.documentfile.provider.DocumentFile;
import android.provider.DocumentsContract;
import android.database.*;
import android.provider.DocumentsContract.Document;

public class ListskinAndroid11Activity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> map1 = new HashMap<>();
	private  Uri muri;
	private  DocumentFile mfile;
	private  Uri urit;
	private  Uri suri;
	private  DocumentFile path;
	private  DocumentFile path1;
	private  DocumentFile file1;
	private  DocumentFile file2;
	private  DocumentFile f3;
	private  DocumentFile f4;
	private  DocumentFile filepath;
	private  Uri uri1;
	private  static final int NEW_FOLDER_REQUEST_CODE = 43;
	private  Runnable runnable;
	private double size = 0;
	private double sumCount = 0;
	private String file = "";
	private String filename = "";
	private String release = "";
	private  Uri uri2;
	private  DocumentFile mfile1;
	private HashMap<String, Object> map1_post = new HashMap<>();
	private HashMap<String, Object> map1_request = new HashMap<>();
	private String Id = "";
	private String Details = "";
	
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap1_post = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear9;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView imageview1;
	private LinearLayout linear7;
	private TextView textview1;
	private LinearLayout linear8;
	private TextView textview2;
	private ImageView imageview2;
	private LinearLayout linear10;
	private LinearLayout linear13;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private TextView textview5;
	private LinearLayout linear14;
	private LinearLayout linear16;
	private TextView textview4;
	private JazzyListView listview1;
	private LinearLayout linear15;
	private CardView card;
	private ImageView image;
	private LinearLayout container;
	private LinearLayout linear17;
	private CircleImageView circleimageview1;
	private LinearLayout linear19;
	private LinearLayout linear18;
	private TextView textview3;
	
	private Intent intent = new Intent();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private SharedPreferences sp;
	private TimerTask timer;
	private Toast CustomToast;
	private AlertDialog CustomDialog;
	private RequestNetwork post;
	private RequestNetwork.RequestListener _post_request_listener;
	private RequestNetwork date;
	private RequestNetwork.RequestListener _date_request_listener;
	private Calendar calendar = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.listskin_android11);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		imageview1 = findViewById(R.id.imageview1);
		linear7 = findViewById(R.id.linear7);
		textview1 = findViewById(R.id.textview1);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		imageview2 = findViewById(R.id.imageview2);
		linear10 = findViewById(R.id.linear10);
		linear13 = findViewById(R.id.linear13);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		textview5 = findViewById(R.id.textview5);
		linear14 = findViewById(R.id.linear14);
		linear16 = findViewById(R.id.linear16);
		textview4 = findViewById(R.id.textview4);
		listview1 = findViewById(R.id.listview1);
		linear15 = findViewById(R.id.linear15);
		card = findViewById(R.id.card);
		image = findViewById(R.id.image);
		container = findViewById(R.id.container);
		linear17 = findViewById(R.id.linear17);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear19 = findViewById(R.id.linear19);
		linear18 = findViewById(R.id.linear18);
		textview3 = findViewById(R.id.textview3);
		net = new RequestNetwork(this);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		post = new RequestNetwork(this);
		date = new RequestNetwork(this);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_post_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				AlphaToast(ListskinAndroid11Activity.this,"Request Sent",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				AlphaToast(ListskinAndroid11Activity.this,"Faild to Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
		};
		
		_date_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				calendar = Calendar.getInstance();
				map1_post = new HashMap<>();
				map1_post.put("Type", "Hero");
				map1_post.put("Details", Details.trim());
				map1_post.put("Accept", "Pending");
				map1_post.put("Time", new SimpleDateFormat("hh:mm a dd/MMM/yy").format(calendar.getTime()));
				map1_post.put("Id", Id.trim());
				listmap1_post.add(map1_post);
				map1_request.put("data", new Gson().toJson(map1_post));
				post.setParams(map1_request, RequestNetworkController.REQUEST_BODY);
				post.startRequestNetwork(RequestNetworkController.POST, "https://sheetdb.io/api/v1/mwd2azigurm64", "", _post_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				AlphaToast(ListskinAndroid11Activity.this,"Faild to Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				_Progress(false);
			}
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =ListskinAndroid11Activity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF0B141A);
		}
		android.graphics.drawable.GradientDrawable linear3gd = new android.graphics.drawable.GradientDrawable();
		
		linear3gd.setColor(0xFF121F2B);
		
		linear3gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear3gd.setCornerRadii(new float[]{(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15,(int)15});
		
		linear3.setBackground(linear3gd);
		
		linear3.setElevation(50);
		android.graphics.drawable.GradientDrawable linear12gd = new android.graphics.drawable.GradientDrawable();
		
		linear12gd.setColor(0xFF121F2B);
		
		linear12gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear12gd.setCornerRadii(new float[]{(int)0,(int)0,(int)0,(int)0,(int)30,(int)30,(int)30,(int)30});
		
		linear12.setBackground(linear12gd);
		
		linear12.setElevation(50);
		android.graphics.drawable.GradientDrawable linear13gd = new android.graphics.drawable.GradientDrawable();
		
		linear13gd.setColor(0xFF121F2B);
		
		linear13gd.setStroke((int)0, Color.TRANSPARENT);
		
		linear13gd.setCornerRadii(new float[]{(int)30,(int)30,(int)30,(int)30,(int)0,(int)0,(int)0,(int)0});
		
		linear13.setBackground(linear13gd);
		
		linear13.setElevation(50);
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF0B141A);
			SketchUi.setCornerRadius(d*10);
			linear15.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
			linear15.setBackground(SketchUiRD);
			linear15.setClickable(true);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF101010);
			SketchUi.setCornerRadius(d*5);
			linear18.setElevation(d*5);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
			linear18.setBackground(SketchUiRD);
			linear18.setClickable(true);
		}
		card.setCardBackgroundColor(Color.TRANSPARENT);
		card.setRadius((float)15);
		((ViewGroup) image.getParent()).removeView(image);
		((ViewGroup) container.getParent()).removeView(container);
		android.widget.RelativeLayout rl = new android.widget.RelativeLayout(ListskinAndroid11Activity.this);
		
		rl.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
		
		card.removeAllViews();
		
		card.addView(rl);
		
		rl.addView(image);
		
		rl.addView(container);
		release = Build.VERSION.RELEASE;
		textview2.setText("Android ".concat(release));
		listview1.setHorizontalScrollBarEnabled(false);
		listview1.setVerticalScrollBarEnabled(false);
		listview1.setOverScrollMode(ListView.OVER_SCROLL_NEVER);
		listview1.setTransitionEffect(new com.twotoasters.jazzylistview.effects.SlideInEffect());
		listview1.setDivider(null);listview1.setDividerHeight(0);
		listview1.setSelector(android.R.color.transparent);
		textview5.setEllipsize(TextUtils.TruncateAt.MARQUEE); textview5.setText("Please wait for the images to load to avoid any errors."); textview5.setSelected(true); textview5.setSingleLine(true);
		_setTransitionName(circleimageview1, "p");
		_OnCreate();
		_PushDown();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		    if (_data != null) {
				               muri = _data.getData();
				if (Uri.decode(muri.toString()).endsWith(":")) {
						AlphaToast(ListskinAndroid11Activity.this,"Can't use root folder please choose another",(int)12,0xFFFFFFFF,0xFF0B141A,160,(int)BOTTOM);
				}
				else {
						final int takeFlags = intent.getFlags()
						            & (Intent.FLAG_GRANT_READ_URI_PERMISSION
						            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
						// Check for the freshest data.
						getContentResolver().takePersistableUriPermission(muri, takeFlags);
						sp.edit().putString("FOLDER_URI", muri.toString()).commit();
						    mfile = DocumentFile.fromTreeUri(this, muri);
						                    
						    mfile1 = mfile.createFile("*/*", "test.file");
						    uri2 = mfile1.getUri();
						sp.edit().putString("DIRECT_FOLDER_URI", uri2.toString().substring((int)(0), (int)(uri2.toString().length() - 9))).commit();
						try{
								        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), uri2);
								     
								        } catch (FileNotFoundException e) {
								         
								    }             
				}
				       } else {
				        
				   }
		    if (_resultCode == Activity.RESULT_OK) {
				        CustomDialog.dismiss();
				AlphaToast(ListskinAndroid11Activity.this,"Permission Granted",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				       } else {
				       CustomDialog.dismiss();
				AlphaToast(ListskinAndroid11Activity.this,"Permission Denied",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				   }
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		intent.setClass(getApplicationContext(), ListCategoryActivity.class);
		intent.putExtra("category", getIntent().getStringExtra("Category"));
		intent.putExtra("list", getIntent().getStringExtra("List"));
		startActivity(intent);
		overridePendingTransition(R.anim.fin, R.anim.fout);
	}
	
	public void _setTransitionName(final View _view, final String _transitionName) {
		_view.setTransitionName(_transitionName);
	}
	
	
	public void _OnCreate() {
		if (getIntent().hasExtra("skin1")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin1"));
			map1.put("img2", getIntent().getStringExtra("logo1"));
			map1.put("txt1", getIntent().getStringExtra("size1"));
			if (getIntent().hasExtra("script1")) {
				map1.put("inject", getIntent().getStringExtra("script1"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin2")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin2"));
			map1.put("img2", getIntent().getStringExtra("logo2"));
			map1.put("txt1", getIntent().getStringExtra("size2"));
			if (getIntent().hasExtra("script2")) {
				map1.put("inject", getIntent().getStringExtra("script2"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin3")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin3"));
			map1.put("img2", getIntent().getStringExtra("logo3"));
			map1.put("txt1", getIntent().getStringExtra("size3"));
			if (getIntent().hasExtra("script3")) {
				map1.put("inject", getIntent().getStringExtra("script3"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin4")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin4"));
			map1.put("img2", getIntent().getStringExtra("logo4"));
			map1.put("txt1", getIntent().getStringExtra("size4"));
			if (getIntent().hasExtra("script4")) {
				map1.put("inject", getIntent().getStringExtra("script4"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin5")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin5"));
			map1.put("img2", getIntent().getStringExtra("logo5"));
			map1.put("txt1", getIntent().getStringExtra("size5"));
			if (getIntent().hasExtra("script5")) {
				map1.put("inject", getIntent().getStringExtra("script5"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin6")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin6"));
			map1.put("img2", getIntent().getStringExtra("logo6"));
			map1.put("txt1", getIntent().getStringExtra("size6"));
			if (getIntent().hasExtra("script6")) {
				map1.put("inject", getIntent().getStringExtra("script6"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin7")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin7"));
			map1.put("img2", getIntent().getStringExtra("logo7"));
			map1.put("txt1", getIntent().getStringExtra("size7"));
			if (getIntent().hasExtra("script7")) {
				map1.put("inject", getIntent().getStringExtra("script7"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin8")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin8"));
			map1.put("img2", getIntent().getStringExtra("logo8"));
			map1.put("txt1", getIntent().getStringExtra("size8"));
			if (getIntent().hasExtra("script8")) {
				map1.put("inject", getIntent().getStringExtra("script8"));
			}
			listmap1.add(map1);
		}
		if (getIntent().hasExtra("skin9")) {
			map1 = new HashMap<>();
			map1.put("img1", getIntent().getStringExtra("skin9"));
			map1.put("img2", getIntent().getStringExtra("logo9"));
			map1.put("txt1", getIntent().getStringExtra("size9"));
			if (getIntent().hasExtra("script9")) {
				map1.put("inject", getIntent().getStringExtra("script9"));
			}
			listmap1.add(map1);
		}
		listview1.setAdapter(new Listview1Adapter(listmap1));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
		if (getIntent().hasExtra("landscape")) {
			Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("landscape"))).into(image);
		}
		if (getIntent().hasExtra("url")) {
			Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("url"))).into(circleimageview1);
		}
		if (getIntent().hasExtra("name")) {
			textview1.setText(getIntent().getStringExtra("name"));
		}
		if (getIntent().hasExtra("number")) {
			textview4.setText(getIntent().getStringExtra("number").concat(" Available Skin's"));
		}
	}
	
	
	public void _PushDown() {
		PushDownAnim.setPushDownAnimTo(imageview1).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				CustomDialog = new AlertDialog.Builder(ListskinAndroid11Activity.this).create();
				LayoutInflater CustomDialogLI = getLayoutInflater();
				View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.request, null);
				CustomDialog.setView(CustomDialogCV);
				CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
				final LinearLayout l1 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear1);
				final LinearLayout l4 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear4);
				final LinearLayout l6 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear6);
				final LinearLayout l7 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear7);
				final TextView t1 = (TextView)
				CustomDialogCV.findViewById(R.id.textview1);
				android.graphics.drawable.GradientDrawable linear1gd = new android.graphics.drawable.GradientDrawable();
				
				linear1gd.setColor(0xFF0B141D);
				
				linear1gd.setStroke((int)0, Color.TRANSPARENT);
				
				linear1gd.setCornerRadii(new float[]{(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8,(int)8});
				
				linear1.setBackground(linear1gd);
				
				linear1.setElevation(50);
				final EditText edittext1= new EditText(ListskinAndroid11Activity.this);
				
				LinearLayout.LayoutParams l1par = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
				
				edittext1.setLayoutParams(l1par);
				
				l7.addView(edittext1);
				t1.setText("I D - ".concat(Build.HOST));
				edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF121F2B));
				edittext1.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
				edittext1.setAlpha((float)(0.8d));
				edittext1.setTextColor(0xFFBDBDBD);
				edittext1.setTextSize((float) 12);
				edittext1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 100)});
				edittext1.setHint("Name of Skin");
				edittext1.setHintTextColor(0xFF757575);
				edittext1.setCursorVisible(false);
				l4.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						if (SketchwareUtil.isConnected(getApplicationContext())) {
							if (edittext1.getText().toString().length() == 0) {
								AlphaToast(ListskinAndroid11Activity.this,"Invalid Request",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
							}
							else {
								date.startRequestNetwork(RequestNetworkController.GET, "http://flexydev.atwebpages.com/api/date.php", "", _date_request_listener);
								Id = Build.HOST;
								Details = edittext1.getText().toString();
								edittext1.setText("");
								CustomDialog.dismiss();
								_Progress(true);
							}
						}
						else {
							AlphaToast(ListskinAndroid11Activity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
						}
					}
				});
				l6.setOnClickListener(new View.OnClickListener(){
					@Override
					public void onClick(View _view){
						CustomDialog.dismiss();
					}
				});
				CustomDialog.setCancelable(false);
				CustomDialog.show();
				 } } );
		PushDownAnim.setPushDownAnimTo(imageview2).setScale(PushDownAnim.MODE_STATIC_DP, 3) 
		.setOnClickListener( new View.OnClickListener(){ @Override public void onClick( View view ){ 
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("android-app://com.mobile.legends"));
				startActivity(intent);
				 } } );
		linear18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (SketchwareUtil.isConnected(getApplicationContext())) {
					_DetectA11Backup();
				}
				else {
					AlphaToast(ListskinAndroid11Activity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				}
			}
		});
	}
	
	
	public void _xtra() {
	}
	
	Boolean Ikuza (DocumentFile srcZipFile, DocumentFile destDir) {
		
		try {
			
			ZipEntry entry; 
			InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
			
			BufferedInputStream bis = new BufferedInputStream(inputStream);
			
			java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
			
			
			 
			while ((entry = zipInputStream.getNextEntry()) != null) { 
				DocumentFile currentDestDir = destDir; 
				DocumentFile parentDir = destDir; 
				DocumentFile childDir = null;
				
				if (entry.toString().endsWith("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					
					 for (String st : tempStr) { 
						
						String meta = Arrays.toString(tempStr);
						if(meta == "Ui"){
							childDir = parentDir.findFile(meta.toUpperCase());
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}else{
							childDir = parentDir.findFile(st);
							if (childDir == null) { 
								
								childDir = parentDir.createDirectory(st);
								//swtchend
							} 
						}
						
						 
						parentDir = childDir; 
					} 
					// returns null 
				}
				
				else if (entry.toString().contains("/")) { 
					
					String[] tempStr = entry.toString().split("/"); 
					
					for (int i = 0; i < tempStr.length - 1; i++) { 
						
						childDir = parentDir.findFile(tempStr[i]); 
						
						if (childDir == null){ 
							childDir = parentDir.createDirectory(tempStr[i]); } 
						parentDir = childDir; 
					} 
					String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
					
					unzipFile(entry, zipInputStream, parentDir);
					
					
					 } // Like ---> / 
				else if (entry.toString().equals("/")) 
				{
					 
					 } else { 
					unzipFile(entry, zipInputStream, destDir);
					
					
				}
			}
			inputStream.close(); 
			 }catch(IOException e1){
			//toast
			SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
			return false;
			 } 
		return true;
		
	} 
	private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
		 int readLen; 
		
		if (!fileEntry.isDirectory()) {
			DocumentFile tempFile = null;
			DocumentFile df = null;
											
											
											//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
			
			
			tempFile = DocumentFile.fromSingleUri(this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
			
			
			if (tempFile.exists()) {
				
				df = tempFile;
					
			}else {
				
				df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
			}
				
			try {
				
				OutputStream out = getContentResolver().openOutputStream(df.getUri());
												BufferedOutputStream bos = new BufferedOutputStream(out);
				long zipfilesize = fileEntry.getSize();
				
				byte[] buffer = new byte[4096];
												int len = 0;
												int totlen = 0;
				
				int count = -1;
				while ((count = zipInputStream.read(buffer)) != -1)
				{
					out.write(buffer, 0, count);
				}
				out.close(); 
				bos.close();
				
				 }catch(Exception e2){
				//toast
				SketchwareUtil.showMessage(getApplicationContext(), e2.toString());
				
			}
			
		}
		 }
	
	{
	}
	boolean hasManageExternalStoragePermission() 
	{
		 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) { 
			if (Environment.isExternalStorageManager()) {
				 return true;
				 } else {
				 if (Environment.isExternalStorageLegacy()) { return true; 
				} 
				try { 
					Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
					)); 
					startActivityForResult(intent, 1);
					  
					return false; 
				} catch (Exception e) { 
					return false; 
				}
				 }
			 } 
		{
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { 
				if (Environment.isExternalStorageLegacy()) { 
					return true;
					 } else {
					 try { 
						Intent intent = new Intent(); intent.setAction(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION); intent.setData(Uri.parse("package:".concat(getApplicationContext().getPackageName().toString())
						)); 
						startActivityForResult(intent, 1); 
						
						return false;
						 } catch (Exception e) { 
						return true; 
					} 
				} 
			}
			 return true; 
		}
	}
	Boolean CyberUnzip(String destDir,String fileZip){
		try
		{
			java.io.File outdir = new java.io.File(destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			return false;
		}
		return true;
		
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	{
	}
	
	
	public void _Auto_Inject() {
	}
	private class CyberTask11 extends AsyncTask<String, Integer, String> {
		KProgressHUD hud;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			hud = new KProgressHUD(ListskinAndroid11Activity.this).setStyle(KProgressHUD.Style.ANNULAR_DETERMINATE).setLabel("Please Wait..")
			.setMaxProgress(100);
			 
			hud.show();
			
		}
		String filename = "";
		String result = "";
		double size = 0;
		double sumCount = 0;
		 @Override
		protected String doInBackground(String... address) {
				try {
						filename= URLUtil.guessFileName(address[0], null, null);
						
						urit = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
				path = DocumentFile.fromTreeUri(ListskinAndroid11Activity.this, urit);
				    path1 = path.createFile("*/*", filename.toLowerCase());
						int resCode = -1;
						java.io.InputStream in = null;
						java.net.URL url = new java.net.URL(address[0]);
						java.net.URLConnection urlConn = url.openConnection();
						if (!(urlConn instanceof java.net.HttpURLConnection)) {
								throw new java.io.IOException("URL is not an Http URL"); }
						java.net.HttpURLConnection httpConn = (java.net.HttpURLConnection) urlConn; httpConn.setAllowUserInteraction(false); httpConn.setInstanceFollowRedirects(true); httpConn.setRequestMethod("GET"); httpConn.connect();
						resCode = httpConn.getResponseCode();
						if (resCode == java.net.HttpURLConnection.HTTP_OK) {
								in = httpConn.getInputStream();
								size = httpConn.getContentLength();
								
						} else { result = "There was an error"; }
				OutputStream output = getContentResolver().openOutputStream(path1.getUri());
						
						try {
								int bytesRead;
								sumCount = 0;
								byte[] buffer = new byte[1024];
								while ((bytesRead = in.read(buffer)) != -1) {
										output.write(buffer, 0, bytesRead);
										sumCount += bytesRead;
										if (size > 0) {
												publishProgress((int)Math.round(sumCount*100 / size));
										}
								}
						} finally {
								output.close();
						}
						result ="";
						in.close();
				} catch (java.net.MalformedURLException e) {
						result = e.getMessage();
				} catch (java.io.IOException e) {
						result = e.getMessage();
				} catch (Exception e) {
						result = e.toString();
				}
				return result;
				
		}
		@Override
		protected void onProgressUpdate(Integer... values) {
				super.onProgressUpdate(values);
				hud.setProgress(values[values.length - 1]);
			hud.setDetailsLabel(String.valueOf((long)(values[values.length - 1])).concat("%"));
		}
		protected void onPostExecute(String s){
				file = filename;
				suri = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
			urit = Uri.parse(sp.getString("DIRECT_FOLDER_URI", "").concat(filename.toLowerCase()));
				filepath = DocumentFile.fromTreeUri(ListskinAndroid11Activity.this, urit);
				Decompress d = new Decompress(filepath, path, ListskinAndroid11Activity.this); 
				d.execute();
		}
	}
	private class Decompress extends AsyncTask<Void, Integer, Integer> { 
		DocumentFile srcZipFile;
		DocumentFile destDir;
		Context ctx;
		int result = 0;
		
		 
		
		public Decompress(DocumentFile srcZipFile, DocumentFile destDir, Context ctx) {
			super();		
			this.srcZipFile = srcZipFile; 		
			this.destDir = destDir;		
			this.ctx = ctx;
		}
		
		@Override	protected void onPreExecute() {
			 
			
		}
		
		@Override
		protected Integer doInBackground(Void... params){		
			int count = 0;
			
			
			try {
				ZipEntry entry; 
				InputStream inputStream = getContentResolver().openInputStream(srcZipFile.getUri()); 
				
				BufferedInputStream bis = new BufferedInputStream(inputStream);
				
				java.util.zip.ZipInputStream zipInputStream = new java.util.zip.ZipInputStream(bis);
				
				int numFiles = 0;
				
				 
				
				
				while ((entry = zipInputStream.getNextEntry()) != null) { 
					DocumentFile currentDestDir = destDir; 
					DocumentFile parentDir = destDir; 
					DocumentFile childDir = null;
					count++;
					publishProgress((int)count);
					
					if (entry.toString().endsWith("/")) { 
						
						String[] tempStr = entry.toString().split("/"); 
						
						
						 for (String st : tempStr) { 
							
							if (st == "UI"){
								childDir = parentDir.findFile(st.toUpperCase());
								
								if (childDir == null) { 
									childDir = parentDir.createDirectory(st);
								}
								
							}else{
								childDir = parentDir.findFile(st);
								
								if (childDir == null) { 
									childDir = parentDir.createDirectory(st);
								}
								
							}
							 
							parentDir = childDir; 
						} 
						// returns null 
					}
					
					else if (entry.toString().contains("/")) { 
						
						String[] tempStr = entry.toString().split("/"); 
						
						for (int i = 0; i < tempStr.length - 1; i++) { 
							
							childDir = parentDir.findFile(tempStr[i]); 
							
							if (childDir == null){ 
								childDir = parentDir.createDirectory(tempStr[i]); } 
							parentDir = childDir; 
						} 
						String finalFileName = entry.toString().substring(entry.toString().lastIndexOf("/") + 1); 
						
						unzipFile(entry, zipInputStream, parentDir);
						
						
						 } // Like ---> / 
					else if (entry.toString().equals("/")) 
					{
						 
						 } else { 
						unzipFile(entry, zipInputStream, destDir);
						
						
					}
				}
				inputStream.close(); 
				 }catch(IOException e1){
				//toast
				SketchwareUtil.showMessage(getApplicationContext(), e1.toString());
				
				 } 
			
			return result;
			
		} 
		private void unzipFile(ZipEntry fileEntry, java.util.zip.ZipInputStream zipInputStream, DocumentFile finalDir) throws IOException {
			 int readLen; 
			
			if (!fileEntry.isDirectory()) {
				DocumentFile tempFile = null;
				DocumentFile df = null;
												
												
												//Now you have to tell it what file extensions ("MIME" type) you want to use, e.g.:
				
				
				tempFile = DocumentFile.fromSingleUri(ListskinAndroid11Activity.this, Uri.parse(finalDir.getUri().toString().concat(Uri.encode("/").concat(Uri.parse(fileEntry.toString()).getLastPathSegment()))));
				
				
				if (tempFile.exists()) {
					
					df = tempFile;
						
				}else {
					
					df = finalDir.createFile("*/*",  Uri.parse(fileEntry.toString()).getLastPathSegment());
				}
					
				try {
					
					OutputStream out = getContentResolver().openOutputStream(df.getUri());
													BufferedOutputStream bos = new BufferedOutputStream(out);
					long zipfilesize = fileEntry.getSize();
					
					byte[] buffer = new byte[4096];
													int len = 0;
													int totlen = 0;
					
					int count = -1;
					while ((count = zipInputStream.read(buffer)) != -1)
					{
						out.write(buffer, 0, count);
					}
					out.close(); 
					bos.close();
					
					 }catch(Exception e2){
					//toast
					SketchwareUtil.showMessage(getApplicationContext(), e2.toString());
					
				}
				
			}
			
		}
		
		protected void onProgressUpdate(Integer... progress) {	
				if (sp.getString("show", "").equals("")) {
				sp.edit().putString("show", ".").commit();
				CustomDialog = new AlertDialog.Builder(ListskinAndroid11Activity.this).create();
				LayoutInflater CustomDialogLI = getLayoutInflater();
				View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.unzip_dialog, null);
				CustomDialog.setView(CustomDialogCV);
				CustomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
				final LinearLayout l2 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear2);
				final LinearLayout l3 = (LinearLayout)
				CustomDialogCV.findViewById(R.id.linear3);
				final TextView t2 = (TextView)
				CustomDialogCV.findViewById(R.id.textview2);
				{
						android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
						int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
						SketchUi.setColor(0xFFE0E0E0);SketchUi.setCornerRadii(new float[]{
								d*10,d*10,d*0 ,d*0,d*0,d*0 ,d*10,d*10});
						l2.setBackground(SketchUi);
				}
				{
						android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
						int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
						SketchUi.setColor(0xFF121F2B);SketchUi.setCornerRadii(new float[]{
								d*0,d*0,d*10 ,d*10,d*10,d*10 ,d*0,d*0});
						l3.setBackground(SketchUi);
				}
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								t2.setText(sp.getString("extra", ""));
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(timer, (int)(0), (int)(100));
				CustomDialog.setCancelable(false);
				CustomDialog.show();
			}
			sp.edit().putString("extra", String.valueOf(progress[progress.length - 1]).concat(" File Extracted..")).commit();
		}
		@Override
		protected void onPostExecute(Integer result) {
			filepath = DocumentFile.fromTreeUri(ListskinAndroid11Activity.this, urit);
			try{
				        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), urit);
				    if (SketchwareUtil.isConnected(getApplicationContext())) {
					urit = Uri.parse(sp.getString("DIRECT_FOLDER_URI", "").concat(file.toLowerCase()));
					timer.cancel();
					sp.edit().remove("show").commit();
					CustomDialog.dismiss();
					LayoutInflater CustomToastLT = getLayoutInflater(); 
					View CustomToastVT = CustomToastLT.inflate(R.layout.success, null);
					Toast CustomToastT = Toast.makeText(getApplicationContext(),"",500);
					CustomToastT.setView(CustomToastVT);
					CustomToastT.show();
				}
				else {
					AlphaToast(ListskinAndroid11Activity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				}
				        } catch (FileNotFoundException e) {
				        AlphaToast(ListskinAndroid11Activity.this,"Failed to inject",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				    }             
		}
	}
	
	
	public void _MoreBlocks() {
	}
	int BOTTOM = 3;
	int TOP = 1;
	int CENTER = 2;
	
	public void AlphaToast(Context context, String str, int i, int i2, int i3, int i4, int i5){
		Toast makeText = Toast.makeText(context,str, 0);
		        View view = makeText.getView();
		        TextView textView = (TextView) view.findViewById(16908299);
		        textView.setTextSize(i);
		        textView.setTextColor(i2);
		        textView.setGravity(i5);
		        GradientDrawable gradientDrawable = new GradientDrawable();
		        gradientDrawable.setColor(i3);
		        gradientDrawable.setCornerRadius(i4);
		        view.setBackgroundDrawable(gradientDrawable);
		        view.setPadding(15, 10, 15, 10);
		        view.setElevation(10.0f);
		
		        switch (i5) {
			            case 1:
			                makeText.setGravity(48, 0, 150);
			                break;
			            case 2:
			                makeText.setGravity(17, 0, 0);
			                break;
			            case 3:
			                makeText.setGravity(80, 0, 150);
			                break;
			        }
		        makeText.show();
	}
	{
	}
	
	
	public void _DetectA11(final double _position, final ArrayList<HashMap<String, Object>> _data) {
		 if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
				      
			try {
				
				     muri = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
				    mfile = DocumentFile.fromTreeUri(this, muri);
				                    
				if (!mfile.canRead() || !mfile.canWrite()) {
					_PermissionDialog();
				}
				else {
					if (_data.get((int)_position).containsKey("inject")) {
						sp.edit().remove("show").commit();
						new CyberTask11().execute(_data.get((int)_position).get("inject").toString());
					}
					else {
						AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
				}
				
				      } catch (Exception e) {
				
				     _PermissionDialog();
				
			}
					        
				    } else {
				      
				    if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
									requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
							}
							else {
					if (_data.get((int)_position).containsKey("inject")) {
						DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
						z.show( getSupportFragmentManager(),"");
						sp.edit().putString("link", _data.get((int)_position).get("inject").toString()).commit();
					}
					else {
						AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
							}
					}
					else {
				if (_data.get((int)_position).containsKey("inject")) {
					DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
					z.show( getSupportFragmentManager(),"");
					sp.edit().putString("link", _data.get((int)_position).get("inject").toString()).commit();
				}
				else {
					AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				}
					}  
				    }
	}
	
	
	public void _PermissionDialog() {
		CustomDialog = new AlertDialog.Builder(ListskinAndroid11Activity.this).create();
		LayoutInflater CustomDialogLI = getLayoutInflater();
		View CustomDialogCV = (View) CustomDialogLI.inflate(R.layout.dialog, null);
		CustomDialog.setView(CustomDialogCV);
		CustomDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);  CustomDialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
		final ImageView i1 = (ImageView)
		CustomDialogCV.findViewById(R.id.imageview1);
		final TextView t1 = (TextView)
		CustomDialogCV.findViewById(R.id.textview1);
		final TextView t2 = (TextView)
		CustomDialogCV.findViewById(R.id.textview2);
		final TextView t3 = (TextView)
		CustomDialogCV.findViewById(R.id.textview3);
		final Button b1 = (Button)
		CustomDialogCV.findViewById(R.id.button1);
		final LinearLayout l1 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear3);
		final LinearLayout l2 = (LinearLayout)
		CustomDialogCV.findViewById(R.id.linear2);
		android.graphics.drawable.GradientDrawable i1gd = new android.graphics.drawable.GradientDrawable();
		
		i1gd.setColor(0xFF2196F3);
		
		i1gd.setStroke((int)0, Color.TRANSPARENT);
		
		i1gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
		
		i1.setBackground(i1gd);
		
		i1.setElevation(5);
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF2196F3);
			SketchUi.setCornerRadius(d*160);
			android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFFFFFFF}), SketchUi, null);
			b1.setBackground(SketchUiRD);
			b1.setClickable(true);
		}
		android.graphics.drawable.GradientDrawable l2gd = new android.graphics.drawable.GradientDrawable();
		
		l2gd.setColor(0xFF2196F3);
		
		l2gd.setStroke((int)0, Color.TRANSPARENT);
		
		l2gd.setCornerRadii(new float[]{(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100,(int)100});
		
		l2.setBackground(l2gd);
		
		l2.setElevation(5);
		android.graphics.drawable.GradientDrawable l1gd = new android.graphics.drawable.GradientDrawable();
		
		l1gd.setColor(0xFFFFFFFF);
		
		l1gd.setStroke((int)0, Color.TRANSPARENT);
		
		l1gd.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)50});
		
		l1.setBackground(l1gd);
		
		l1.setElevation(5);
		i1.setElevation((float)0.3d);
		i1.setImageResource(R.drawable.storage);
		t1.setText("Android 11 Detected");
		t2.setText("You need to allow storage permission to use app, Please grant access so that the app could run properly.");
		t3.setText("permission");
		b1.setText("Allow");
		b1.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View _view){
				_askPermissionA11(linear1);
			}
		});
		 
		CustomDialog.setCancelable(true);
		CustomDialog.show();
	}
	
	
	public void _askPermissionA11(final View _view) {
		intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
		intent.setAction(Intent.ACTION_OPEN_DOCUMENT_TREE);
		muri = Uri.parse("content://com.android.externalstorage.documents/tree/primary%3AAndroid/document/primary%3AAndroid%2Fdata%2Fcom.mobile.legends%2Ffiles%2Fdragon2017");
		    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, muri);
		        startActivityForResult(intent, NEW_FOLDER_REQUEST_CODE);
	}
	
	
	public void _DetectA11Backup() {
		 if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
				      
			try {
				
				     muri = Uri.parse(sp.getString("DIRECT_FOLDER_URI", ""));
				    mfile = DocumentFile.fromTreeUri(this, muri);
				                    
				if (!mfile.canRead() || !mfile.canWrite()) {
					_PermissionDialog();
				}
				else {
					if (getIntent().hasExtra("backup")) {
						sp.edit().remove("show").commit();
						new CyberTask11().execute(getIntent().getStringExtra("backup"));
					}
					else {
						AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
				}
				
				      } catch (Exception e) {
				
				     _PermissionDialog();
				
			}
					        
				    } else {
				      
				    if (Build.VERSION.SDK_INT >= 23) {
							if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
									requestPermissions(new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
							}
							else {
					if (getIntent().hasExtra("backup")) {
						DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
						z.show( getSupportFragmentManager(),"");
						sp.edit().putString("link", getIntent().getStringExtra("backup")).commit();
					}
					else {
						AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
							}
					}
					else {
				if (getIntent().hasExtra("backup")) {
					DownloaderDialogFragmentActivity z = new DownloaderDialogFragmentActivity();
					z.show( getSupportFragmentManager(),"");
					sp.edit().putString("link", getIntent().getStringExtra("backup")).commit();
				}
				else {
					AlphaToast(ListskinAndroid11Activity.this,"No link Available",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
				}
					}  
				    }
	}
	
	
	public void _Progress(final boolean _ifShow) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
				
				prog.requestWindowFeature(Window.FEATURE_NO_TITLE);  prog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			prog.setMessage(null);
			prog.show();
			prog.setContentView(R.layout.loading);
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.skin, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout container = _view.findViewById(R.id.container);
			final androidx.cardview.widget.CardView card = _view.findViewById(R.id.card);
			final ImageView image = _view.findViewById(R.id.image);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF0B141A);
				SketchUi.setCornerRadius(d*10);
				linear1.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear1.setBackground(SketchUiRD);
				linear1.setClickable(true);
			}
			{
				android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
				int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
				SketchUi.setColor(0xFF101010);
				SketchUi.setCornerRadius(d*5);
				linear7.setElevation(d*5);
				android.graphics.drawable.RippleDrawable SketchUiRD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF9E9E9E}), SketchUi, null);
				linear7.setBackground(SketchUiRD);
				linear7.setClickable(true);
			}
			((ViewGroup) image.getParent()).removeView(image);
			((ViewGroup) container.getParent()).removeView(container);
			android.widget.RelativeLayout rl = new android.widget.RelativeLayout(ListskinAndroid11Activity.this);
			
			rl.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
			
			card.removeAllViews();
			
			card.addView(rl);
			
			rl.addView(image);
			
			rl.addView(container);
			Animation animation; animation = AnimationUtils.loadAnimation( getApplicationContext(), android.R.anim.fade_in ); animation.setDuration(700); image.startAnimation(animation); animation = null;
			linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF22485E));
			card.setCardBackgroundColor(Color.TRANSPARENT);
			card.setRadius((float)15);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("img1").toString())).into(image);
			textview2.setText(_data.get((int)_position).get("txt1").toString().concat(" MB"));
			linear7.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (SketchwareUtil.isConnected(getApplicationContext())) {
						_DetectA11(_position, _data);
					}
					else {
						AlphaToast(ListskinAndroid11Activity.this,"Please check your internet connection",(int)12,0xFFFFFFFF,0xFF0B141A,100,(int)BOTTOM);
					}
				}
			});
			if (_data.get((int)_position).get("img2").toString().equals("Normal")) {
				imageview1.setVisibility(View.INVISIBLE);
			}
			else {
				if (_data.get((int)_position).get("img2").toString().equals("Seasonal")) {
					imageview1.setVisibility(View.INVISIBLE);
				}
				else {
					if (_data.get((int)_position).get("img2").toString().equals("M - World")) {
						imageview1.setVisibility(View.INVISIBLE);
					}
					else {
						if (_data.get((int)_position).get("img2").toString().equals("Annual")) {
							Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/annual_starlight_skin_tag.png")).into(imageview1);
							imageview1.setVisibility(View.VISIBLE);
						}
						else {
							if (_data.get((int)_position).get("img2").toString().equals("Collector")) {
								Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/collector_skin_tag.png")).into(imageview1);
								imageview1.setVisibility(View.VISIBLE);
							}
							else {
								if (_data.get((int)_position).get("img2").toString().equals("Elite")) {
									Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/elite_skin_tag.png")).into(imageview1);
									imageview1.setVisibility(View.VISIBLE);
								}
								else {
									if (_data.get((int)_position).get("img2").toString().equals("Epic")) {
										Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/epic_skin_tag.png")).into(imageview1);
										imageview1.setVisibility(View.VISIBLE);
									}
									else {
										if (_data.get((int)_position).get("img2").toString().equals("515")) {
											Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/five_one_five_skin_tag.png")).into(imageview1);
											imageview1.setVisibility(View.VISIBLE);
										}
										else {
											if (_data.get((int)_position).get("img2").toString().equals("Hero")) {
												Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/hero_skin_tag.png")).into(imageview1);
												imageview1.setVisibility(View.VISIBLE);
											}
											else {
												if (_data.get((int)_position).get("img2").toString().equals("Kof")) {
													Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/kof_skin_tag.png")).into(imageview1);
													imageview1.setVisibility(View.VISIBLE);
												}
												else {
													if (_data.get((int)_position).get("img2").toString().equals("Legend")) {
														Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/legend_skin_tag.png")).into(imageview1);
														imageview1.setVisibility(View.VISIBLE);
													}
													else {
														if (_data.get((int)_position).get("img2").toString().equals("Lightborn")) {
															Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/lightborn_skin_tag.png")).into(imageview1);
															imageview1.setVisibility(View.VISIBLE);
														}
														else {
															if (_data.get((int)_position).get("img2").toString().equals("Limited")) {
																Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/limited_skin_tag.png")).into(imageview1);
																imageview1.setVisibility(View.VISIBLE);
															}
															else {
																if (_data.get((int)_position).get("img2").toString().equals("Mpl")) {
																	Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/mpl_skin_tag.png")).into(imageview1);
																	imageview1.setVisibility(View.VISIBLE);
																}
																else {
																	if (_data.get((int)_position).get("img2").toString().equals("Pacquiao")) {
																		Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/pacquiao_skin_tag.png")).into(imageview1);
																		imageview1.setVisibility(View.VISIBLE);
																	}
																	else {
																		if (_data.get((int)_position).get("img2").toString().equals("Special")) {
																			Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/special_skin_tag.png")).into(imageview1);
																			imageview1.setVisibility(View.VISIBLE);
																		}
																		else {
																			if (_data.get((int)_position).get("img2").toString().equals("Starlight")) {
																				Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/starlight_skin_tag.png")).into(imageview1);
																				imageview1.setVisibility(View.VISIBLE);
																			}
																			else {
																				if (_data.get((int)_position).get("img2").toString().equals("Starwars")) {
																					Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/starwars_skin_tag.png")).into(imageview1);
																					imageview1.setVisibility(View.VISIBLE);
																				}
																				else {
																					if (_data.get((int)_position).get("img2").toString().equals("Stun")) {
																						Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/stun_skin_tag.png")).into(imageview1);
																						imageview1.setVisibility(View.VISIBLE);
																					}
																					else {
																						if (_data.get((int)_position).get("img2").toString().equals("Summer")) {
																							Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/summer_skin_tag.png")).into(imageview1);
																							imageview1.setVisibility(View.VISIBLE);
																						}
																						else {
																							if (_data.get((int)_position).get("img2").toString().equals("Transformers")) {
																								Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/transformers_skin_tag.png")).into(imageview1);
																								imageview1.setVisibility(View.VISIBLE);
																							}
																							else {
																								if (_data.get((int)_position).get("img2").toString().equals("Zodiac")) {
																									Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/zodiac_skin_tag.png")).into(imageview1);
																									imageview1.setVisibility(View.VISIBLE);
																								}
																								else {
																									if (_data.get((int)_position).get("img2").toString().equals("Sanrio")) {
																										Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/sanrio_skin_tag.png")).into(imageview1);
																										imageview1.setVisibility(View.VISIBLE);
																									}
																									else {
																										if (_data.get((int)_position).get("img2").toString().equals("11.11")) {
																											Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/11.11_skin_tag.png")).into(imageview1);
																											imageview1.setVisibility(View.VISIBLE);
																										}
																										else {
																											if (_data.get((int)_position).get("img2").toString().equals("Abyss")) {
																												Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/abyss_skin_tag.png")).into(imageview1);
																												imageview1.setVisibility(View.VISIBLE);
																											}
																											else {
																												if (_data.get((int)_position).get("img2").toString().equals("Aspirant")) {
																													Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/aspirants_skin_tag.png")).into(imageview1);
																													imageview1.setVisibility(View.VISIBLE);
																												}
																												else {
																													if (_data.get((int)_position).get("img2").toString().equals("Christmas")) {
																														Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/christmas_skin_tag.png")).into(imageview1);
																														imageview1.setVisibility(View.VISIBLE);
																													}
																													else {
																														if (_data.get((int)_position).get("img2").toString().equals("Halloween")) {
																															Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/halloween_skin_tag.png")).into(imageview1);
																															imageview1.setVisibility(View.VISIBLE);
																														}
																														else {
																															if (_data.get((int)_position).get("img2").toString().equals("Valentine")) {
																																Glide.with(getApplicationContext()).load(Uri.parse("https://github.com/akosighost/Logo-image/raw/main/valentine_skin_tag.png")).into(imageview1);
																																imageview1.setVisibility(View.VISIBLE);
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}